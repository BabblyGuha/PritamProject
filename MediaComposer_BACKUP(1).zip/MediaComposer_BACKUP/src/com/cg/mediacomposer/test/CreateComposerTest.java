package com.cg.mediacomposer.test;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import com.cg.mediacomposer.bean.ComposerBean;
import com.cg.mediacomposer.dao.ComposerDAO;
import com.cg.mediacomposer.dao.IComposerDAO;
import com.cg.mediacomposer.exception.MediaComposerException;

public class CreateComposerTest {
	IComposerDAO dao=null;
	ComposerBean composer=new ComposerBean();
	long creatorID=9999;
	long Current_Composer_ID=3088;
	
	/*
	 * 
	 * This test method should give True output for insertion of a composer
	 * We check the value returned from addComposer() method in ComposerDAO class
	 * with the current value of Composer_ID_Seq that is the composer_id of last 
	 * inserted record
	 * 
	 */
	@Test
	public void testAddComposer() throws MediaComposerException, IOException {
		dao=new ComposerDAO();
		composer.setComposer_name("test");
		composer.setComposer_musicsocietyid(null);
		composer.setComposer_caeipiNumber(null);
		composer.setComposer_borndate(null);
		composer.setComposer_dieddate(null);
		assertEquals(Current_Composer_ID, dao.addComposer(composer, creatorID));
	}
	
	/*
	 * 
	 * This test method should give False output for insertion of a composer
	 * We check the value returned from addComposer() method in ComposerDAO class
	 * with the a random value other than the current value of Composer_ID_Seq
	 * that is the composer_id of last inserted record
	 * 
	 */
	@Test
	public void testAddComposer1() throws MediaComposerException, IOException {
		dao=new ComposerDAO();
		composer.setComposer_name("test");
		composer.setComposer_musicsocietyid("ABC");
		composer.setComposer_caeipiNumber("test");
		composer.setComposer_borndate(null);
		composer.setComposer_dieddate(null);
		assertEquals(999, dao.addComposer(composer, creatorID));
	}
}
