package com.cg.mediacomposer.test;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import com.cg.mediacomposer.bean.UserBean;
import com.cg.mediacomposer.dao.ArtistDAO;
import com.cg.mediacomposer.dao.IArtistDAO;
import com.cg.mediacomposer.dao.IUserDAO;
import com.cg.mediacomposer.dao.UserDAO;
import com.cg.mediacomposer.exception.MediaComposerException;

public class LoginTest {
	IUserDAO dao = null;
	UserBean user = new UserBean();

	/*
	 * Checks for Admin Login ID and password
	 */
	@Test
	public void testLoginAdmin() throws MediaComposerException, IOException {
		dao = new UserDAO();
		user.setUser_id(1001);
		user.setUser_password("gg");
		assertEquals(1, dao.login(user));
	}

	/*
	 * Checks for User Login ID and password
	 */
	@Test
	public void testLoginUser() throws MediaComposerException, IOException {
		dao = new UserDAO();
		user.setUser_id(2001);
		user.setUser_password("user");
		assertEquals(0, dao.login(user));
	}

	/*
	 * Checks for Invalid Login ID and password
	 */
	@Test
	public void testLoginInvalid() throws MediaComposerException, IOException {
		dao = new UserDAO();
		user.setUser_id(2222);
		user.setUser_password("gggg");
		assertEquals(-1, dao.login(user));
	}
}
