package com.cg.mediacomposer.test;

import static org.junit.Assert.*;

import java.io.IOException;

import org.junit.Test;

import com.cg.mediacomposer.bean.ArtistBean;
import com.cg.mediacomposer.dao.ArtistDAO;
import com.cg.mediacomposer.dao.IArtistDAO;
import com.cg.mediacomposer.exception.MediaComposerException;

public class UpdateArtistTest {
	IArtistDAO dao=null;
	ArtistBean artist=new ArtistBean();
	long creatorID=9999;
	
	/*
	 * This Test method gives output True as we update against a valid Artist ID
	 */
	@Test
	public void testUpdateArtist() throws MediaComposerException, IOException {
		dao=new ArtistDAO();
		artist.setArtist_id(1063);
		artist.setArtist_name("TestName");
		assertEquals(1, dao.updateArtist(artist, creatorID, 1));
	}
	
	
	/*
	 * This Test method gives output False as we try to update against a Invalid Artist ID
	 */
	@Test
	public void testUpdateArtist1() throws MediaComposerException, IOException {
		dao=new ArtistDAO();
		artist.setArtist_id(9999);
		artist.setArtist_name("TestName");
		assertEquals(1, dao.updateArtist(artist, creatorID, 1));
	}
}
