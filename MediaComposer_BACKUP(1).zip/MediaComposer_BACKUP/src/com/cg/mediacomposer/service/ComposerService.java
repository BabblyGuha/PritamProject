package com.cg.mediacomposer.service;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.ComposerBean;
import com.cg.mediacomposer.dao.ComposerDAO;
import com.cg.mediacomposer.dao.IComposerDAO;
import com.cg.mediacomposer.exception.MediaComposerException;
import com.cg.mediacomposer.ui.ClientUI;

public class ComposerService implements IComposerService {
IComposerDAO dao=new ComposerDAO();
	@Override
	public long addComposer(ComposerBean composer, long creatorID) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		try{
		/*if(composer.getComposer_borndate().toLocalDate().getYear()>LocalDate.now().getYear()){
			//composer.setComposer_borndate(null);
			System.out.println("Born date cannot be greater then current date");
			return -1;
		}
		if(composer.getComposer_dieddate()!=null)
		if(composer.getComposer_dieddate().toLocalDate().getYear()>LocalDate.now().getYear()){
			//composer.setComposer_dieddate(null);
			System.out.println("Died date cannot be greater then current date");
			return -1;
		}*/
		if(composer.getComposer_dieddate()!=null && composer.getComposer_borndate()!=null){
			if(composer.getComposer_borndate().toLocalDate().getYear()>composer.getComposer_dieddate().toLocalDate().getYear())
			{
				/*composer.setComposer_borndate(null);
				composer.setComposer_dieddate(null);*/
				System.out.println("Born Date cannot be greater than died date!!");
				//System.out.println("Composer Born date and Died Date both set to NULL");
				return -1;
			}
		}
		
		
		if (!(composer.getComposer_musicsocietyid().toUpperCase().equals("ABC") || composer.getComposer_musicsocietyid().toUpperCase().equals("XYZ")))
			composer.setComposer_musicsocietyid(null);
		}catch(Exception e){
			System.out.println("Problem occurs while processing input data!!");
			ClientUI.adminComposerAction(creatorID);
		}
		return dao.addComposer(composer,creatorID);
	}
	@Override
	public int deleteComposer(long composerid) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.deleteComposer(composerid);
	}
	@Override
	public ComposerBean searchComposer(long composerid) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.searchComposer(composerid);
	}
	@Override
	public ArrayList<ComposerBean> viewAllComposer() throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.viewAllComposer();
	}
	@Override
	public int updateComposer(ComposerBean composer, long creatorID, int i) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		if(!(composer.getComposer_musicsocietyid() ==null))
		if (!(composer.getComposer_musicsocietyid().equals("ABC") || composer.getComposer_musicsocietyid().equals("XYZ")))
			composer.setComposer_musicsocietyid(null);
		/*if(composer.getComposer_borndate()!=null)
		if(composer.getComposer_borndate().toLocalDate().getYear()>LocalDate.now().getYear())
			//composer.setComposer_borndate(null);
			return -1;*/
		/*if(composer.getComposer_dieddate()!=null)
			if(composer.getComposer_dieddate().toLocalDate().getYear()>LocalDate.now().getYear())
				//composer.setComposer_borndate(null);
				return -1;*/
		return dao.updateComposer(composer, creatorID,i);
	}
	@Override
	public int checkComposer(long composerid) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.checkComposer(composerid);
	}
	@Override
	public ArrayList<ComposerBean> getAllComposerID() throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.getAllComposerID();
	}
	
	

}
