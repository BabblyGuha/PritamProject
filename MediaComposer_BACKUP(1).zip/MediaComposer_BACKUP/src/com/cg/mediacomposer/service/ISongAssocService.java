package com.cg.mediacomposer.service;

import java.io.IOException;

import com.cg.mediacomposer.exception.MediaComposerException;

public interface ISongAssocService {
	public abstract int addSongArtistAssoc(long songid, long artistid,
			long creatorid) throws MediaComposerException, IOException;

	public abstract int addSongComposerAssoc(long songid, long composerid,
			long creatorID) throws MediaComposerException, IOException;
}
