package com.cg.mediacomposer.service;

import java.io.IOException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.UserBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public interface IUserService {
	public abstract int login(UserBean user) throws MediaComposerException, IOException;

	public abstract int addUser(UserBean user, long creatorID) throws MediaComposerException, IOException;

	public abstract int deleteUser(long userid) throws MediaComposerException, IOException;

	public abstract int updateUserPassword(long userid, String password,
			long creatorID) throws MediaComposerException, IOException;

	public abstract UserBean searchUser(long userid) throws MediaComposerException, IOException;

	public abstract ArrayList<UserBean> viewAllUser() throws MediaComposerException, IOException;
}
