package com.cg.mediacomposer.service;

import java.io.IOException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.ArtistBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public interface IArtistService {
	public abstract long addArtist(ArtistBean artist, long creatorID)
			throws MediaComposerException, IOException;

	public abstract int deleteArtist(long artistid)
			throws MediaComposerException, IOException;

	public abstract ArrayList<ArtistBean> viewAllArtist()
			throws MediaComposerException, IOException;

	public abstract ArtistBean searchArtist(long artistid)
			throws MediaComposerException, IOException;

	public abstract int updateArtist(ArtistBean artist, long creatorID, int i)
			throws MediaComposerException, IOException;

	public abstract int checkArtist(long artistid)
			throws MediaComposerException, IOException;

	public ArrayList<ArtistBean> getAllArtistID() throws MediaComposerException, IOException;

	//public long getCurrentArtistID() throws MediaComposerException;
}
