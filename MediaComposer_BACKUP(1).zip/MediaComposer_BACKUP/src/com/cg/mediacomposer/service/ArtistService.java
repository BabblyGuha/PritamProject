package com.cg.mediacomposer.service;

import java.io.IOException;
import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.ArtistBean;
import com.cg.mediacomposer.dao.ArtistDAO;
import com.cg.mediacomposer.dao.IArtistDAO;
import com.cg.mediacomposer.exception.MediaComposerException;
import com.cg.mediacomposer.ui.ClientUI;

public class ArtistService implements IArtistService {
IArtistDAO dao=new ArtistDAO();
	@Override
	public long addArtist(ArtistBean artist, long creatorID) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		/*try{
		if(artist.getArtist_borndate().toLocalDate().getYear()>LocalDate.now().getYear()){
			//artist.setArtist_borndate(null);
			System.out.println("Born date cannot be greater then current date");
			return -1;
		}
		if(!(artist.getArtist_dieddate()==null))
		if(artist.getArtist_dieddate().toLocalDate().getYear()>LocalDate.now().getYear()){
			//artist.setArtist_dieddate(null);
			System.out.println("Died date cannot be greater then current date");
			return -1;
		}
		if(artist.getArtist_dieddate()!=null && artist.getArtist_borndate()!=null){
			if(artist.getArtist_borndate().toLocalDate().getYear()>artist.getArtist_dieddate().toLocalDate().getYear())
			{
				artist.setArtist_borndate(null);
				artist.setArtist_dieddate(null);
				System.out.println("Born Date cannot be greater than died date!!");
				//System.out.println("Artist Born date and Died Date both set to NULL");
				return -1;
			}
		}
		if(artist.getArtist_type().length()>1){
			System.out.println("Artist Type cannot be more than one Character!!");
			return -1;
		}
		}catch(Exception e){
			System.out.println("Problem occurs while processing input data!!");
			ClientUI.adminArtistAction(creatorID);
		}*/
		return dao.addArtist(artist, creatorID);
	}

	@Override
	public int deleteArtist(long artistid) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.deleteArtist(artistid);
	}

	@Override
	public ArrayList<ArtistBean> viewAllArtist() throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.viewAllArtist();
	}

	@Override
	public ArtistBean searchArtist(long artistid) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.searchArtist(artistid);
	}

	@Override
	public int updateArtist(ArtistBean artist, long creatorID, int i) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		/*if(artist.getArtist_borndate()!=null){
		if(artist.getArtist_borndate().toLocalDate().getYear()>LocalDate.now().getYear())
			//artist.setArtist_borndate(null);
			return -1;
		}
		if(artist.getArtist_dieddate()!=null){
			if(artist.getArtist_dieddate().toLocalDate().getYear()>LocalDate.now().getYear())
				//artist.setArtist_borndate(null);
				return -1;
			}*/
		return dao.updateArtist(artist, creatorID,i);
	}
	public int checkArtist(long artistid) throws MediaComposerException, IOException{
		return dao.checkArtist(artistid);
	}

	@Override
	public ArrayList<ArtistBean> getAllArtistID() throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.getAllArtistID();
	}

	//@Override
	/*public long getCurrentArtistID() throws MediaComposerException {
		// TODO Auto-generated method stub
		return dao.getCurrentArtistID();
	}*/
	/*public boolean validateBornDate(Date bDate){
		if(bDate!=null){
			if(bDate.)
		}
	}*/
}
