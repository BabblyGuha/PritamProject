package com.cg.mediacomposer.service;

import java.io.IOException;

import com.cg.mediacomposer.dao.ISongAssocDAO;
import com.cg.mediacomposer.dao.SongAssocDAO;
import com.cg.mediacomposer.exception.MediaComposerException;

public class SongAssocService implements ISongAssocService {
ISongAssocDAO dao=new SongAssocDAO();
	@Override
	public int addSongArtistAssoc(long songid, long artistid, long creatorid) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.addSongArtistAssoc(songid, artistid, creatorid);
	}
	@Override
	public int addSongComposerAssoc(long songid, long composerid, long creatorID) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.addSongComposerAssoc(songid, composerid, creatorID);
	}

}
