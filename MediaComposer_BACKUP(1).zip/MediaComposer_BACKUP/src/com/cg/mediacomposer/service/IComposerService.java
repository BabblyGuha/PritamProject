package com.cg.mediacomposer.service;

import java.io.IOException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.ComposerBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public interface IComposerService {

	public abstract long addComposer(ComposerBean composer, long creatorID) throws MediaComposerException, IOException;

	public abstract int deleteComposer(long composerid) throws MediaComposerException, IOException;

	public abstract ComposerBean searchComposer(long composerid) throws MediaComposerException, IOException;

	public abstract ArrayList<ComposerBean> viewAllComposer() throws MediaComposerException, IOException;

	public abstract int updateComposer(ComposerBean composer, long creatorID, int i) throws MediaComposerException, IOException;
	
	public abstract int checkComposer(long composerid) throws MediaComposerException, IOException;
	
	public ArrayList<ComposerBean> getAllComposerID() throws  MediaComposerException, IOException;

}
