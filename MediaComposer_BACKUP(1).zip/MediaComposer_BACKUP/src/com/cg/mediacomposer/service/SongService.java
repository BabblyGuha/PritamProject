package com.cg.mediacomposer.service;

import java.io.IOException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.SongBean;
import com.cg.mediacomposer.dao.ISongDAO;
import com.cg.mediacomposer.dao.SongDAO;
import com.cg.mediacomposer.exception.MediaComposerException;

public class SongService implements ISongService {
	ISongDAO dao=null;
	@Override
	public ArrayList<Long> getAllSongID() throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		dao=new SongDAO();
		return dao.getAllSongID();
	}
	@Override
	public int checkSong(long songid) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		dao=new SongDAO();
		return dao.checkSong(songid);
	}
	@Override
	public ArrayList<SongBean> viewAllSong() throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		dao=new SongDAO();
		return dao.viewAllSong();
	}

}
