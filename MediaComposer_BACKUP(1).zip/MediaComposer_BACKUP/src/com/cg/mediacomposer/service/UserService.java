package com.cg.mediacomposer.service;

import java.io.IOException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.UserBean;
import com.cg.mediacomposer.dao.IUserDAO;
import com.cg.mediacomposer.dao.UserDAO;
import com.cg.mediacomposer.exception.MediaComposerException;

public class UserService implements IUserService {
IUserDAO dao=new UserDAO();
	@Override
	public int login(UserBean user) throws MediaComposerException, IOException {
		return dao.login(user);
	}

	@Override
	public int addUser(UserBean user, long creatorID) throws MediaComposerException, IOException {
		return dao.addUser(user, creatorID);
	}

	@Override
	public int deleteUser(long userid) throws MediaComposerException, IOException {
		return dao.deleteUser(userid);
	}

	@Override
	public int updateUserPassword(long userid, String password, long creatorID) throws MediaComposerException, IOException {
		return dao.updateUserPassword(userid, password, creatorID);
	}

	@Override
	public UserBean searchUser(long userid) throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.searchUser(userid);
	}

	@Override
	public ArrayList<UserBean> viewAllUser() throws MediaComposerException, IOException {
		// TODO Auto-generated method stub
		return dao.viewAllUser();
	}

}
