package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.SongBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public interface IUserActionDAO {
	public abstract ArrayList<SongBean> getSongByArtist(long artistid) throws MediaComposerException, IOException;

	public abstract ArrayList<SongBean> getSongByComposer(long composerid) throws MediaComposerException, IOException;
}
