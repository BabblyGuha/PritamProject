package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;





import com.cg.mediacomposer.bean.UserBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public class UserDAO implements IUserDAO,IQueryMapper{
	Connection conn = null;

	
	/*
	 * 
	 * Login Logic
	 * Checks if the given Username and Password exists in the database
	 * Returns -1 if not found
	 * Returns 1 if Admin
	 * Returns 0 if User 
	 *  
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	login()
	 - Input Parameters	:	Userbean
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Checks USerID and PAssword for Login
	 ********************************************************************************************************/
	
	
	public int login(UserBean user) throws MediaComposerException, IOException{
		conn = DBUtil.getConnection();
		int n = -1;
		try {
			String c = "";
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.LOGIN);
			pstmt.setLong(1, user.getUser_id());
			pstmt.setString(2, user.getUser_password());
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				c = rs.getString(7);

			}
			if ("A".equals(c))
				n = 1;
			else if ("U".equals(c))
				n = 0;
			else
				n = -1;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}

	
	/*
	 * Add new user
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	addUser()
	 - Input Parameters	:	Userbean,long
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Adds records in USer_MAster table
	 ********************************************************************************************************/
	
	public int addUser(UserBean user, long creatorID) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		int n = 0, c=0;
		try {
			PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.GET_USER_ID);
			pstmt1.setLong(1, user.getUser_id());
			ResultSet rs=pstmt1.executeQuery();
			while(rs.next())
			{
				if(user.getUser_id()==rs.getLong(1))
					c=1;
			}
			if(c==0) {
				PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.INSERT_USER);
				pstmt.setLong(1, user.getUser_id());
				pstmt.setString(2, user.getUser_password());
				pstmt.setLong(3, creatorID);
				pstmt.setString(4, user.getUser_type());
				n = pstmt.executeUpdate();
			}
			conn.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return n;
	}
	
	
	
	/*
	 * Delete User by ID
	 */

	public int deleteUser(long userid) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		int n = 0;
		String c = "";
		try {
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.GET_USER_TYPE);
			pstmt.setLong(1, userid);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				c = rs.getString(1);
				if ("A".equals(c))
					n = -1;
				else if ("U".equals(c)) {
					PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.DELETE_USER);
					pstmt1.setLong(1, userid);
					n = pstmt1.executeUpdate();
				} else
					n = 0;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}
	
	
	/*
	 * Update User by ID
	 */

	public int updateUserPassword(long userid, String password, long creatorID) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		int n = 0;
		String c = "";
		try {
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.GET_USER_TYPE);
			pstmt.setLong(1, userid);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				c = rs.getString(1);
				if ("A".equals(c))
					n = -1;
				else if ("U".equals(c)) {
					PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.UPDATE_USER);
					pstmt1.setString(1, password);
					pstmt1.setLong(2, creatorID);
					pstmt1.setLong(3, userid);
					n = pstmt1.executeUpdate();
				} else
					n = 0;

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}

	
	/*
	 * Search USer by ID
	 */

	public UserBean searchUser(long userid) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		UserBean user = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.SEARCH_USER);
			pstmt.setLong(1, userid);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				if(userid==rs.getLong(1)){
				user = new UserBean();
				user.setUser_id(userid);
				user.setUser_password(rs.getString(2));
				user.setCreated_by(rs.getLong(3));
				user.setCreated_on(rs.getDate(4));
				user.setUpdated_by(rs.getLong(5));
				user.setUpdated_on(rs.getDate(6));
				user.setUser_type(rs.getString(7));
				}
				
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return user;
	}
	
	
	
	/*
	 * Displays All User
	 */
	public ArrayList<UserBean> viewAllUser() throws MediaComposerException, IOException {
		ArrayList<UserBean> userList=new ArrayList<>();
		conn=DBUtil.getConnection();
			try {
				PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.VIEW_ALL_USER);
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					long userid=rs.getLong(1);
					String password=rs.getString(2);
					long createdBy=rs.getLong(3);
					Date createdOn=rs.getDate(4);
					long updatedBy=rs.getLong(5);
					Date updatedOn=rs.getDate(6);
					String userType=rs.getString(7);
					UserBean user=new UserBean();
					user.setUser_id(userid);
					user.setUser_password(password);
					user.setUser_type(userType);
					user.setCreated_by(createdBy);
					user.setCreated_on((java.sql.Date) createdOn);
					user.setUpdated_by(updatedBy);
					user.setUpdated_on((java.sql.Date) updatedOn);
					userList.add(user);
					}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		return userList;
	}

}
