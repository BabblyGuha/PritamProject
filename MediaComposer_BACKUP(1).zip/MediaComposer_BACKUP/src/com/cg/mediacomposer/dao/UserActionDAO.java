package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.SongBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public class UserActionDAO implements IUserActionDAO,IQueryMapper{
	public Connection conn = null;

	
	
	/*
	 * 
	 * This method takes ArtistID as Input and returns List of all Songs associated with that Artist
	 * 
	 */
	
	/*******************************************************************************************************
	 - Function Name	:	 getSongByArtist()
	 - Input Parameters	:	long
	 - Return Type		:	ArrayList<SongBean>
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Displays all songs associated with given Artist ID
	 ********************************************************************************************************/
	public ArrayList<SongBean> getSongByArtist(long artistid) throws MediaComposerException, IOException {
		conn=DBUtil.getConnection();
		ArrayList<SongBean> songList = new ArrayList<>();
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.CHECK_SONG_IN_ARTIST__SONG_ASSOC);
			pstmt.setLong(1, artistid);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				// if(rs.getLong(1)==null){
				PreparedStatement pstmt1 = conn
						.prepareStatement(IQueryMapper.GET_SONG_DETAILS);
				pstmt1.setLong(1, rs.getLong(1));
				ResultSet rs1=pstmt1.executeQuery();
				while(rs1.next()){
					SongBean song = new SongBean();
					song.setSongID(rs1.getLong(1));
					song.setSongName(rs1.getString(2));
					song.setSong_duration(rs1.getString(3));
					song.setCreatedBY(rs1.getLong(4));
					song.setCreatedOn(rs1.getDate(5));
					song.setUpdatedBY(rs1.getLong(6));
					song.setUpdatedOn(rs1.getDate(7));
					songList.add(song);
				}
				
				// }
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return songList;
	}
	
	
	
	/*
	 * 
	 * This method takes ComposerID as Input and returns List of all Songs associated with that Composer
	 * 
	 */
	

	/*******************************************************************************************************
	 - Function Name	:	 getSongByComposer()
	 - Input Parameters	:	long
	 - Return Type		:	ArrayList<SongBean>
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Displays all songs associated with given Composer ID
	 ********************************************************************************************************/
	
	@Override
	public ArrayList<SongBean> getSongByComposer(long composerid) throws MediaComposerException, IOException {
		conn=DBUtil.getConnection();
		ArrayList<SongBean> songList = new ArrayList<>();
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.CHECK_SONG_IN_COMPOSER__SONG_ASSOC);
			pstmt.setLong(1, composerid);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				// if(rs.getLong(1)==null){
				PreparedStatement pstmt1 = conn
						.prepareStatement(IQueryMapper.GET_SONG_DETAILS);
				pstmt1.setLong(1, rs.getLong(1));
				ResultSet rs1=pstmt1.executeQuery();
				while(rs1.next()){
					SongBean song = new SongBean();
					song.setSongID(rs1.getLong(1));
					song.setSongName(rs1.getString(2));
					song.setSong_duration(rs1.getString(3));
					song.setCreatedBY(rs1.getLong(4));
					song.setCreatedOn(rs1.getDate(5));
					song.setUpdatedBY(rs1.getLong(6));
					song.setUpdatedOn(rs1.getDate(7));
					songList.add(song);
				}
				
				// }
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return songList;
	}

}
