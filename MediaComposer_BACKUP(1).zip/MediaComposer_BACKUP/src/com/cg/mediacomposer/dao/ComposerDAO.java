package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.cg.mediacomposer.bean.ArtistBean;
import com.cg.mediacomposer.bean.ComposerBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public class ComposerDAO implements IComposerDAO,IQueryMapper {
	Connection conn = null;
	@Override
	
	/*
	 * Inserting new Composer Details
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	addComposer()
	 - Input Parameters	:	ComposerBean,long
	 - Return Type		:	long
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Adds a new Composer
	 ********************************************************************************************************/
	
	
	public long addComposer(ComposerBean composer, long creatorID) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		long n = 0;
		try {
			
				PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.INSERT_COMPOSER);
				pstmt.setString(1, composer.getComposer_name());
				pstmt.setDate(2, composer.getComposer_borndate());
				pstmt.setDate(3, composer.getComposer_dieddate());
				pstmt.setString(4, composer.getComposer_caeipiNumber());
				pstmt.setString(5, composer.getComposer_musicsocietyid());
				pstmt.setLong(6, creatorID);
				n = pstmt.executeUpdate();
				if(n==1){
					PreparedStatement pstmt1=conn.prepareStatement(IQueryMapper.GET_CURRENT_COMPOSER_ID);
					ResultSet rs1=pstmt1.executeQuery();
					rs1.next();
						n=rs1.getLong(1);
				}
			conn.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return n;
	}
	
	
	/*
	 * Delete Composer by ID
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	deleteComposer()
	 - Input Parameters	:	long
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Deletes a Composer
	 ********************************************************************************************************/
	
	
	@Override
	public int deleteComposer(long composerid) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		int n = 0;
		try {
			
					PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.DELETE_COMPOSER);
					pstmt1.setLong(1, composerid);
					n = pstmt1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}



	/*
	 * Search Composer by ID
	 */

	
	/*******************************************************************************************************
	 - Function Name	:	searchComposer()
	 - Input Parameters	:	long
	 - Return Type		:	ComposerBean
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Search for a Composer
	 ********************************************************************************************************/
	
	
	@Override
	public ComposerBean searchComposer(long composerid) throws MediaComposerException, IOException {
		ComposerBean composerBean=null;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.SEARCH_COMPOSER);
			pstmt.setLong(1, composerid);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				String composername=rs.getString(2);
				Date borndate=rs.getDate(3);
				Date dieddate=rs.getDate(4);
				String caeipi=rs.getString(5);
				String msociety=rs.getString(6);
				long createdby=rs.getLong(7);
				Date createdon=rs.getDate(8);
				long updatedby=rs.getLong(9);
				Date updatedon=rs.getDate(10);
				String deletedflag=rs.getString(11);
				composerBean=new ComposerBean(composername,(java.sql.Date)borndate, (java.sql.Date)dieddate,caeipi,msociety);
				composerBean.setComposer_id(composerid);
				composerBean.setCreated_by(createdby);
				composerBean.setCreated_on((java.sql.Date)createdon);
				composerBean.setUpdated_by(updatedby);
				composerBean.setUpdated_on((java.sql.Date)updatedon);
				composerBean.setComposer_deletedflag(deletedflag);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	return composerBean;
	}


	/*
	 * View All Composer
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	viewAllComposer()
	 - Input Parameters	:	none
	 - Return Type		:	ArrayList<ComposerBean>
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Displays All composer details
	 ********************************************************************************************************/


	@Override
	public ArrayList<ComposerBean> viewAllComposer() throws MediaComposerException, IOException {
		ArrayList<ComposerBean> composerList=new ArrayList<>();
		conn=DBUtil.getConnection();
			try {
				PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.VIEW_COMPOSER);
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					long composerid=rs.getLong(1);
					String composername=rs.getString(2);
					Date borndate=rs.getDate(3);
					Date dieddate=rs.getDate(4);
					String caeipi=rs.getString(5);
					String msociety=rs.getString(6);
					long createdby=rs.getLong(7);
					Date createdon=rs.getDate(8);
					long updatedby=rs.getLong(9);
					Date updatedon=rs.getDate(10);
					String deletedflag=rs.getString(11);
					ComposerBean composerBean=new ComposerBean(composername,(java.sql.Date)borndate, (java.sql.Date)dieddate,caeipi,msociety);
					composerBean.setComposer_id(composerid);
					composerBean.setCreated_by(createdby);
					composerBean.setCreated_on((java.sql.Date)createdon);
					composerBean.setUpdated_by(updatedby);
					composerBean.setUpdated_on((java.sql.Date)updatedon);
					composerBean.setComposer_deletedflag(deletedflag);
					composerList.add(composerBean);
					}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		return composerList;
	}


	/*
	 * Update Composer by ID
	 */

	
	
	/*******************************************************************************************************
	 - Function Name	:	updateComposer()
	 - Input Parameters	:	ComposerBean,long, int
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Updates a new Composer
	 ********************************************************************************************************/

	@Override
	public int updateComposer(ComposerBean composer, long creatorID, int i) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		int n = 0;
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHECK_COMPOSER);
			pstmt.setLong(1, composer.getComposer_id());
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				
				if(rs.getLong(1)==composer.getComposer_id()){
					PreparedStatement pstmt1=null;
					switch (i) {
					case 1:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_COMPOSER_NAME);
						pstmt1.setString(1, composer.getComposer_name());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, composer.getComposer_id());
						n=pstmt1.executeUpdate();
						break;
					case 2:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_COMPOSER_CAEIPI_NUMBER);
						pstmt1.setString(1, composer.getComposer_caeipiNumber());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, composer.getComposer_id());
						n=pstmt1.executeUpdate();
						break;
					case 3:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_COMPOSER_MUSICSOCIETY_ID);
						pstmt1.setString(1, composer.getComposer_musicsocietyid());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, composer.getComposer_id());
						n=pstmt1.executeUpdate();
						break;
					case 4:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_COMPOSER_BORNDATE);
						pstmt1.setDate(1, composer.getComposer_borndate());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, composer.getComposer_id());
						n=pstmt1.executeUpdate();
						break;
					case 5:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_COMPOSER_DIEDDATE);
						pstmt1.setDate(1, composer.getComposer_dieddate());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, composer.getComposer_id());
						n=pstmt1.executeUpdate();
						break;

					default:
						break;
					}
					
				}
					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return n;
	}
	
	/*
	 * 
	 * This function checks if a composer ID exists in the database or not
	 * 
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	checkComposer()
	 - Input Parameters	:	long
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Checks for the validity of a composer ID
	 ********************************************************************************************************/
	
	public int checkComposer(long composerid) throws MediaComposerException, IOException {
		int n=0;
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHECK_COMPOSER);
			pstmt.setLong(1, composerid);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				if(rs.getLong(1)==composerid){
					n=1;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	
	}
	
	
	/*
	 * 
	 * This function returns all the existing ComposerId and their Names
	 * 
	 */
	
	/*******************************************************************************************************
	 - Function Name	:	getAllComposerID()
	 - Input Parameters	:	none
	 - Return Type		:	ArrayList<ComposerBean>
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Displays all the composer ID along with their names
	 ********************************************************************************************************/
	
	
	public ArrayList<ComposerBean> getAllComposerID() throws  MediaComposerException, IOException{
		ArrayList<ComposerBean> list=new ArrayList<>();
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.GET_ALL_COMPOSER_ID);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				ComposerBean composer=new ComposerBean();
				composer.setComposer_id(rs.getLong(1));
				composer.setComposer_name(rs.getString(2));
				list.add(composer);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}

}
