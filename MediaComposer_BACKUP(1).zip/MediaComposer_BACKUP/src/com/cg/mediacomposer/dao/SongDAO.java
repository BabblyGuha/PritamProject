package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.ArtistBean;
import com.cg.mediacomposer.bean.SongBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public class SongDAO implements ISongDAO,IQueryMapper {
	Connection conn = null;

	
	/*
	 * 
	 * This metgod returns the list of all songId
	 * 
	 */
	
	/*******************************************************************************************************
	 - Function Name	:	getAllSongID()
	 - Input Parameters	:	None
	 - Return Type		:	ArrayList<Long>
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Displays all Song IDs
	 ********************************************************************************************************/
	
	@Override
	public ArrayList<Long> getAllSongID() throws MediaComposerException, IOException {
		ArrayList<Long> list = new ArrayList<>();
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pstmt = conn
					.prepareStatement(IQueryMapper.GET_ALL_SONG_ID);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				list.add(rs.getLong(1));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	/*
	 * 
	 * This method checks if a given song ID exists in the Database or not
	 * 
	 */
	
	/*******************************************************************************************************
	 - Function Name	:	checkSong()
	 - Input Parameters	:	long
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Checks validity of a song ID
	 ********************************************************************************************************/
	
	public int checkSong(long songid) throws MediaComposerException, IOException {
		int n=0;
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHECK_SONG);
			pstmt.setLong(1, songid);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				if(rs.getLong(1)==songid){
					n=1;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	
	}
	
	
	/*
	 *
	 * This method returns the list of all songs
	 * 
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	viewAllSong()
	 - Input Parameters	:	none
	 - Return Type		:	ArrayList<SongBean>
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Displays all Songs details
	 ********************************************************************************************************/
	
	
	public ArrayList<SongBean> viewAllSong() throws MediaComposerException, IOException{
		ArrayList<SongBean> songList=new ArrayList<>();
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.VIEW_SONG);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				SongBean song=new SongBean();
				song.setSongID(rs.getLong(1));
				song.setSongName(rs.getString(2));
				song.setSong_duration(rs.getString(3));
				songList.add(song);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return songList;
	}
}
