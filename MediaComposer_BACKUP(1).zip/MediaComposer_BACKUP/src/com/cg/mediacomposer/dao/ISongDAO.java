package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.util.ArrayList;

import com.cg.mediacomposer.bean.SongBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public interface ISongDAO {
	public ArrayList<Long> getAllSongID() throws MediaComposerException, IOException;
	public int checkSong(long songid) throws MediaComposerException, IOException;
	public ArrayList<SongBean> viewAllSong() throws MediaComposerException, IOException;
}
