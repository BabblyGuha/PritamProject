package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.mediacomposer.exception.MediaComposerException;

public class SongAssocDAO implements ISongAssocDAO ,IQueryMapper{
	Connection conn=null;
	@Override
	
	/*
	 * Add to the Artist_SongAssoc table 
	 * Maps Song_ID with Artist_ID
	 */
	/*******************************************************************************************************
	 - Function Name	:	addSongArtistAssoc()
	 - Input Parameters	:	long,long,long
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Adds in Artist_Song_Assoc Table
	 ********************************************************************************************************/
	public int addSongArtistAssoc(long songid, long artistid, long creatorid) throws MediaComposerException, IOException {
		int n=-1;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHECK_SONG);
			pstmt.setLong(1, songid);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				if(rs.getLong(1)==songid){
					PreparedStatement pstmt1=conn.prepareStatement(IQueryMapper.CHECK_ARTIST);
					pstmt1.setLong(1, artistid);
					ResultSet rs1=pstmt1.executeQuery();
					while(rs1.next()){
						if(rs1.getLong(1)==artistid){
							PreparedStatement pstmt2=conn.prepareStatement(IQueryMapper.INSERT_ARTIST_SONG_ASSOC);
							pstmt2.setLong(1, artistid);
							pstmt2.setLong(2, songid);
							pstmt2.setLong(3, creatorid);
							n=pstmt2.executeUpdate();
						}
						
					}
				}
				else
					n=-1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}
	
	
	
	@Override
	
	/*
	 * Add to the Composer_SongAssoc table 
	 * Maps Song_ID with Composer_ID
	 */
	
	/*******************************************************************************************************
	 - Function Name	:	addSongComposerAssoc()
	 - Input Parameters	:	long,long,long
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Adds in Composer_Song_Assoc Table
	 ********************************************************************************************************/
	public int addSongComposerAssoc(long songid, long composerid, long creatorID) throws MediaComposerException, IOException {
		int n=-1;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHECK_SONG);
			pstmt.setLong(1, songid);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				if(rs.getLong(1)==songid){
					PreparedStatement pstmt1=conn.prepareStatement(IQueryMapper.CHECK_COMPOSER);
					pstmt1.setLong(1, composerid);
					ResultSet rs1=pstmt1.executeQuery();
					while(rs1.next()){
						if(rs1.getLong(1)==composerid){
							PreparedStatement pstmt2=conn.prepareStatement(IQueryMapper.INSERT_COMPOSER_SONG_ASSOC);
							pstmt2.setLong(1, composerid);
							pstmt2.setLong(2, songid);
							pstmt2.setLong(3, creatorID);
							n=pstmt2.executeUpdate();
						}
						/*else{
							n=0;
							return n;
						}*/
					}
				}
				else
					n=-1;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}

}
