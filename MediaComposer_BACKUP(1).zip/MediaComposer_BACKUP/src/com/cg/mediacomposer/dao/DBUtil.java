package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.mediacomposer.exception.MediaComposerException;
import com.cg.mediacomposer.ui.ClientUI;

public class DBUtil {
	static Logger logger=Logger.getRootLogger();
	
	/*
	 * 
	 * This function establishes connection with the Database and returns Connection object
	 * 
	 */
	public static Connection getConnection() throws MediaComposerException, IOException {
		Connection conn = null;
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			conn = DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl", "trg217","training217");

		} catch (SQLException e) {
			System.err.println("Connection Problem occurs in Database!! Try again later!");
			System.err.println("Redirecting to Login Page");
			logger.error("Connection Problem occurs in Database!!");
			ClientUI.main(null);
		}
		return conn;
	}
}
