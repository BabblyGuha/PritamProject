package com.cg.mediacomposer.dao;

public interface IQueryMapper {

	/*
	 * Queries related to User_Master Table
	 */
	
	public static final String LOGIN = "select * from user_master where  user_id=? and user_password=?";
	public static final String INSERT_USER = "insert into user_master(user_id,user_password,created_by,created_on,user_type) values(?,?,?,sysdate,?)";
	public static final String DELETE_USER = "delete from user_master where user_id=?";
	public static final String SEARCH_USER = "select * from user_master where user_id=?";
	public static final String VIEW_ALL_USER = "select * from user_master";
	public static final String UPDATE_USER = "update user_master set user_password=?,updated_by=?,updated_on=sysdate where user_id=?";
	public static final String GET_USER_TYPE= "select user_type from user_master where user_id=?";
	public static final String GET_USER_ID="select user_id from user_master where user_id=?";

	/*
	 * Queries related to Artist_Master Table
	 */
	
	public static final String INSERT_ARTIST = "insert into artist_master(artist_id,artist_name,artist_type,artist_borndate,artist_dieddate,created_by,created_on,artist_deletedflag) values (artist_id_seq.nextval,?,?,?,?,?,sysdate,'N')";
	public static final String DELETE_ARTIST = "delete from artist_master where artist_id=?";
	public static final String SEARCH_ARTIST = "select * from artist_master where artist_id=?";
	public static final String VIEW_ARTIST = "select * from artist_master";
	public static final String UPDATE_ARTIST_NAME = "update artist_master set artist_name=?, updated_by=?, updated_on=sysdate where artist_id=?";
	public static final String UPDATE_ARTIST_TYPE = "update artist_master set artist_type=?, updated_by=?, updated_on=sysdate where artist_id=?";
	public static final String UPDATE_ARTIST_BORNDATE = "update artist_master set artist_borndate=?, updated_by=?, updated_on=sysdate where artist_id=?";
	public static final String UPDATE_ARTIST_DIEDDATE = "update artist_master set artist_dieddate=?, updated_by=?, updated_on=sysdate where artist_id=?";
	public static final String CHECK_ARTIST = "select artist_id from artist_master where artist_id=?";
	public static final String GET_ALL_ARTIST_ID="select artist_id,artist_name from artist_master";
	public static final String GET_CURRENT_ARTIST_ID="SELECT artist_id_seq.CURRVAL from dual";
	
	
	/*
	 * Queries related to Composer_Master Table
	 */

	public static final String INSERT_COMPOSER = "insert into composer_master(composer_id,composer_name,composer_borndate,composer_dieddate,composer_caeipinumber,composer_musicsocietyid,created_by,created_on,composer_deletedflag) values (composer_id_seq.nextval,?,?,?,?,?,?,sysdate,'N')";
	public static final String DELETE_COMPOSER = "delete from composer_master where composer_id=?";
	public static final String SEARCH_COMPOSER = "select * from composer_master where composer_id=?";
	public static final String VIEW_COMPOSER = "select * from composer_master";
	public static final String UPDATE_COMPOSER_NAME = "update composer_master set composer_name=?, updated_by=?, updated_on=sysdate where composer_id=?";
	public static final String UPDATE_COMPOSER_CAEIPI_NUMBER = "update composer_master set composer_caeipinumber=?, updated_by=?, updated_on=sysdate where composer_id=?";
	public static final String UPDATE_COMPOSER_MUSICSOCIETY_ID = "update composer_master set composer_musicsocietyid=?, updated_by=?, updated_on=sysdate where composer_id=?";
	public static final String UPDATE_COMPOSER_BORNDATE = "update composer_master set composer_borndate=?, updated_by=?, updated_on=sysdate where composer_id=?";
	public static final String UPDATE_COMPOSER_DIEDDATE = "update composer_master set composer_dieddate=?, updated_by=?, updated_on=sysdate where composer_id=?";
	public static final String CHECK_COMPOSER = "select composer_id from composer_master where composer_id=?";
	public static final String GET_ALL_COMPOSER_ID="select composer_id,composer_name from composer_master";
	public static final String GET_CURRENT_COMPOSER_ID="SELECT composer_id_seq.CURRVAL from dual";

	/*
	 * Queries related to Artist_Song_Assoc Table and Composer_Song_Assoc Table
	 */

	
	public static final String INSERT_ARTIST_SONG_ASSOC = "insert into artist_song_assoc(artist_id,song_id,created_by,created_on) values(?,?,?,sysdate)";
	public static final String INSERT_COMPOSER_SONG_ASSOC = "insert into composer_song_assoc(composer_id,song_id,created_by,created_on) values(?,?,?,sysdate)";

	

	public static final String GET_SONG_DETAILS = "select * from song_master where song_id=?";
	public static final String CHECK_SONG_IN_ARTIST__SONG_ASSOC = "select distinct(song_id) from artist_song_assoc where artist_id=?";
	public static final String CHECK_SONG_IN_COMPOSER__SONG_ASSOC = "select distinct(song_id) from composer_song_assoc where composer_id=?";
	
	/*
	 * Queries related to Song_Master Table
	 */
	
	public static final String CHECK_SONG = "select song_id from song_master where song_id=?";
	public static final String GET_ALL_SONG_ID="select song_id from song_master";
	public static final String VIEW_SONG="select * from song_master";
	
}
