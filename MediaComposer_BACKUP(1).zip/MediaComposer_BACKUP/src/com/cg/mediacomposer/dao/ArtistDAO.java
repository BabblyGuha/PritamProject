package com.cg.mediacomposer.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;

import com.cg.mediacomposer.bean.ArtistBean;
import com.cg.mediacomposer.bean.UserBean;
import com.cg.mediacomposer.exception.MediaComposerException;

public class ArtistDAO implements IArtistDAO,IQueryMapper{
	Connection conn = null;
	
	/*
	 * Inserting New Artist
	 */
	
	/*******************************************************************************************************
	 - Function Name	:	addArtist()
	 - Input Parameters	:	ArtistBean,long
	 - Return Type		:	long
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Add new Artist
	 ********************************************************************************************************/
	
	public long addArtist(ArtistBean artist, long creatorID) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		long n = 0;
		try {
			
				PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.INSERT_ARTIST);
				pstmt.setString(1, artist.getArtist_name());
				pstmt.setString(2, artist.getArtist_type());
				pstmt.setDate(3, artist.getArtist_borndate());
				pstmt.setDate(4, artist.getArtist_dieddate());
				pstmt.setLong(5, creatorID);
				n = pstmt.executeUpdate();
				if(n==1){
					PreparedStatement pstmt1=conn.prepareStatement(IQueryMapper.GET_CURRENT_ARTIST_ID);
					ResultSet rs1=pstmt1.executeQuery();
					rs1.next();
						n=rs1.getLong(1);
				}
			conn.close();
		} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		return n;
	}
	
	/*
	 * Deleting Artist
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	deleteArtist()
	 - Input Parameters	:	long
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Deletes an artist by ID
	 ********************************************************************************************************/
	
	
	public int deleteArtist(long artistid) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		int n = 0;
		try {
			
					PreparedStatement pstmt1 = conn.prepareStatement(IQueryMapper.DELETE_ARTIST);
					pstmt1.setLong(1, artistid);
					n = pstmt1.executeUpdate();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	}
	
	
	/*
	 * View All Artist
	 */
	
	
	/*******************************************************************************************************
	 - Function Name	:	viewAllArtist()
	 - Input Parameters	:	none
	 - Return Type		:	ArrayList<ArtistBean>
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Displays all the Artist
	 ********************************************************************************************************/
	
	
	public ArrayList<ArtistBean> viewAllArtist() throws MediaComposerException, IOException {
		ArrayList<ArtistBean> artistList=new ArrayList<>();
		conn=DBUtil.getConnection();
			try {
				PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.VIEW_ARTIST);
				ResultSet rs = pstmt.executeQuery();

				while (rs.next()) {
					long artistid=rs.getLong(1);
					String artistname=rs.getString(2);
					String artisttype=rs.getString(3);
					Date borndate=rs.getDate(4);
					Date dieddate=rs.getDate(5);
					long createdby=rs.getLong(6);
					Date createdon=rs.getDate(7);
					long updatedby=rs.getLong(8);
					Date updatedon=rs.getDate(9);
					String deletedflag=rs.getString(10);
					ArtistBean artistBean=new ArtistBean(artistname,artisttype,(java.sql.Date)borndate, (java.sql.Date)dieddate);
					artistBean.setArtist_id(artistid);
					artistBean.setCreated_by(createdby);
					artistBean.setCreated_on((java.sql.Date)createdon);
					artistBean.setUpdated_by(updatedby);
					artistBean.setUpdated_on((java.sql.Date)updatedon);
					artistBean.setArtist_deletedflag(deletedflag);
					artistList.add(artistBean);
					}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		return artistList;
	}


	
	/*
	 * Search Artist by ID
	 */

	
	/*******************************************************************************************************
	 - Function Name	:	searchArtist()
	 - Input Parameters	:	long
	 - Return Type		:	ArtistBean
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Search for an Artist
	 ********************************************************************************************************/
	
	
	public ArtistBean searchArtist(long artistid) throws MediaComposerException, IOException {
		ArtistBean artistBean=null;
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pstmt = conn.prepareStatement(IQueryMapper.SEARCH_ARTIST);
			pstmt.setLong(1, artistid);
			ResultSet rs = pstmt.executeQuery();

			while (rs.next()) {
				String artistname=rs.getString(2);
				String artisttype=rs.getString(3);
				Date borndate=rs.getDate(4);
				Date dieddate=rs.getDate(5);
				long createdby=rs.getLong(6);
				Date createdon=rs.getDate(7);
				long updatedby=rs.getLong(8);
				Date updatedon=rs.getDate(9);
				String deletedflag=rs.getString(10);
				artistBean=new ArtistBean(artistname,artisttype,(java.sql.Date)borndate, (java.sql.Date)dieddate);
				artistBean.setArtist_id(artistid);
				artistBean.setCreated_by(createdby);
				artistBean.setCreated_on((java.sql.Date)createdon);
				artistBean.setUpdated_by(updatedby);
				artistBean.setUpdated_on((java.sql.Date)updatedon);
				artistBean.setArtist_deletedflag(deletedflag);
				}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	return artistBean;
	}
	
	
	/*
	 * Update Artist by ID
	 */
	
	/*******************************************************************************************************
	 - Function Name	:	updateArtist()
	 - Input Parameters	:	ArtistBean,long,int
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Updates an Artist Details
	 ********************************************************************************************************/
	
	
	public int updateArtist(ArtistBean artist, long creatorID, int i) throws MediaComposerException, IOException {
		conn = DBUtil.getConnection();
		int n = 0;
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHECK_ARTIST);
			pstmt.setLong(1, artist.getArtist_id());
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				if(rs.getLong(1)==artist.getArtist_id()){
					PreparedStatement pstmt1=null;
					switch (i) {
					case 1:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_ARTIST_NAME);
						pstmt1.setString(1, artist.getArtist_name());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, artist.getArtist_id());
						n=pstmt1.executeUpdate();
						break;
					case 2:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_ARTIST_TYPE);
						pstmt1.setString(1, artist.getArtist_type());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, artist.getArtist_id());
						n=pstmt1.executeUpdate();
						break;
					case 3:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_ARTIST_BORNDATE);
						pstmt1.setDate(1, artist.getArtist_borndate());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, artist.getArtist_id());
						n=pstmt1.executeUpdate();
						break;
					case 4:
						pstmt1=conn.prepareStatement(IQueryMapper.UPDATE_ARTIST_DIEDDATE);
						pstmt1.setDate(1, artist.getArtist_dieddate());
						pstmt1.setLong(2, creatorID);
						pstmt1.setLong(3, artist.getArtist_id());
						n=pstmt1.executeUpdate();
						break;

					default:
						break;
					}
					
				}
					
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return n;
	}
	
	
	
	/*
	 * This function checks the availability of an Artist ID
	 * */
	
	/*******************************************************************************************************
	 - Function Name	:	checkArtist()
	 - Input Parameters	:	long
	 - Return Type		:	int
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Checks validity of a artist ID
	 ********************************************************************************************************/
	
	public int checkArtist(long artistid) throws MediaComposerException, IOException {
		int n=0;
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.CHECK_ARTIST);
			pstmt.setLong(1, artistid);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				if(rs.getLong(1)==artistid){
					n=1;
				}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return n;
	
	}
	
	/*
	 * 
	 * This function returns list of all ArtistId and their Names
	 * 
	 */
	
	/*******************************************************************************************************
	 - Function Name	:	getAllArtistID()
	 - Input Parameters	:	none
	 - Return Type		:	ArrayList<ArtistBean>
	 - Throws			:  	MediaComposerException, IOException
	 - Author			:	Pritam Bhattacharjee
	 - Creation Date	:	27/08/2018
	 - Description		:	Displays all artistID along with their name
	 ********************************************************************************************************/
	
	
	public ArrayList<ArtistBean> getAllArtistID() throws  MediaComposerException, IOException{
		ArrayList<ArtistBean> list=new ArrayList<>();
		conn=DBUtil.getConnection();
		try {
			PreparedStatement pstmt=conn.prepareStatement(IQueryMapper.GET_ALL_ARTIST_ID);
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()){
				ArtistBean artist=new ArtistBean();
				artist.setArtist_id(rs.getLong(1));
				artist.setArtist_name(rs.getString(2));
				list.add(artist);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	
	
	/*
	 * 
	 * Get last inserted Artist ID
	 * */
	
	/*public long getCurrentArtistID() throws MediaComposerException{
		long artistid=0;
		conn=DBUtil.getConnection();
		try{
			PreparedStatement pstmt=conn.prepareStatement("SELECT artist_id_seq.CURRVAL from dual");
			ResultSet rs=pstmt.executeQuery();
			rs.next();
				artistid=rs.getLong(1);
			
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return artistid;
	}*/
}
