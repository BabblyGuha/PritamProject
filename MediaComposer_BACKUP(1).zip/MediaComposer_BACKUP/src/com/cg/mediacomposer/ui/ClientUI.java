package com.cg.mediacomposer.ui;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;



import com.cg.mediacomposer.bean.ArtistBean;
import com.cg.mediacomposer.bean.ComposerBean;
import com.cg.mediacomposer.bean.SongBean;
import com.cg.mediacomposer.bean.UserBean;
import com.cg.mediacomposer.dao.ArtistDAO;
import com.cg.mediacomposer.dao.SongAssocDAO;
import com.cg.mediacomposer.dao.UserDAO;
import com.cg.mediacomposer.exception.MediaComposerException;
import com.cg.mediacomposer.service.ArtistService;
import com.cg.mediacomposer.service.ComposerService;
import com.cg.mediacomposer.service.IArtistService;
import com.cg.mediacomposer.service.IComposerService;
import com.cg.mediacomposer.service.ISongAssocService;
import com.cg.mediacomposer.service.ISongService;
import com.cg.mediacomposer.service.IUserActionService;
import com.cg.mediacomposer.service.IUserService;
import com.cg.mediacomposer.service.SongAssocService;
import com.cg.mediacomposer.service.SongService;
import com.cg.mediacomposer.service.UserActionService;
import com.cg.mediacomposer.service.UserService;

public class ClientUI {
	static Logger logger = Logger.getRootLogger();
	public static final SimpleDateFormat format = new SimpleDateFormat(
			"yyyy-MM-dd");
	public static Scanner scanner = new Scanner(System.in);
	public static IUserService service = null;
	public static IArtistService service1 = null;
	public static IComposerService service2 = null;
	public static ISongAssocService service3 = null;
	public static ISongService service4 = null;
	public static IUserActionService userservice = null;
	
	
	/*
	 * 
	 * Main method()
	 * This method checks for the credentials for Logging in
	 * After checking it redirects to either Admin portal or User portal based on the credentials
	 * 
	 */

	public static void main(String[] args) throws MediaComposerException,
			IOException {

		Scanner sc = new Scanner(System.in);
		System.out.println("******************");
		System.out.println("--Media Composer--");
		System.out.println("******************");
		System.out.println();

		try {
			System.out.println("Enter user ID");
			long usrid = sc.nextLong();
			System.out.println("Enter password");
			String passwrd = sc.next();
			UserBean user = new UserBean();
			user.setUser_id(usrid);
			user.setUser_password(passwrd);
			service = new UserService();
			if (service.login(user) == -1) {
				System.err.println("Invalid User ID or Password");
				logger.error("Invalid User ID or Password");
				main(args);
			} else if (service.login(user) == 1) {
				System.out.println("Welcome Admin");
				logger.info("Admin Login Successfull for user id: " + usrid);
				adminAction(usrid);

			} else if (service.login(user) == 0) {
				System.out.println("Welcome User");
				logger.info("User Login Successfull for user id: " + usrid);
				userAction(usrid);
			}

		} catch (InputMismatchException e) {
			System.err
					.println("Wrong Input pattern for User ID!! It Should be a number!");
			logger.error("Wrong Input pattern for User ID!!");
			main(args);

		}
	}

	/*
	 * 
	 * 
	 * This Method is used for validation of Date input
	 * 
	 */

	public static boolean isValidDate(String input) {
		try {
			format.parse(input);
			return true;
		} catch (ParseException e) {
			return false;
		}
	}

	/*
	 * 
	 * User action method User Action includes-- 
	 * 1. Serach song by Artist 
	 * 2. Search song by Composer
	 * User gives ArtistId or ComposerID and gets the Lists of songs associated with them
	 * 
	 */
	public static void userAction(long userID) throws MediaComposerException,
			IOException {
		Scanner sc = new Scanner(System.in);
		String ch = "y";
		int choice = 0;

		do {
			try {
				System.out.println();
				System.out.println();
				System.out.println("Choose Your Action:");
				System.out.println("1: Search Song by Artist");
				System.out.println("2: Search Song by Composer");
				System.out.println("3: Exit");
				System.out.println();
				System.out.println("Enter Option:");

				choice = sc.nextInt();
			} catch (InputMismatchException e) {
				System.err.println("Wrong Input Entered!!   ");
				userAction(userID);
			}
			switch (choice) {
			case 1:

				userservice = new UserActionService();
				service1 = new ArtistService();
				ArrayList<ArtistBean> list1 = service1.getAllArtistID();
				System.out.println();
				System.out.println("Here is the list of Artist ID-->");

				for (ArtistBean l : list1) {
					System.out.println("ID: " + l.getArtist_id() + "  Name: "
							+ l.getArtist_name());
				}
				System.out.println();
				do {
					try {
						Scanner sc1 = new Scanner(System.in);
						System.out.println("Enter Artist ID:");
						long artistid = sc1.nextLong();
						int check = service1.checkArtist(artistid);
						if (check == 0) {
							System.out.println("Invalid Artist ID");
							continue;
						} else {
							ArrayList<SongBean> songList = new ArrayList<>();
							songList = userservice.getSongByArtist(artistid);
							if (songList.isEmpty()) {
								System.out
										.println("No song found for Artist ID: "
												+ artistid);
								break;
							} else {
								System.out.println();
								System.out.println();
								System.out.println("List of Songs -->");
								System.out.println();
								System.out.println();
								for (SongBean song : songList) {
									/*
									 * System.out .println("Artist ID: " +
									 * artistid);
									 */
									System.out.print("-->>Song ID: "
											+ song.getSongID());
									System.out.print("| Song Name: "
											+ song.getSongName());
									System.out.println("| Song Duration: "
											+ song.getSong_duration());
									/*
									 * System.out.print(" Created By: " +
									 * song.getCreatedBY());
									 * System.out.println(" Creted On: " +
									 * song.getCreatedOn());
									 * System.out.print(" Updated By: " +
									 * song.getUpdatedBY());
									 * System.out.println(" Updated On: " +
									 * song.getUpdatedOn());
									 */
									System.out.println();
									System.out.println();
								}
								break;
							}

						}
					} catch (InputMismatchException e) {
						System.err.println("Input Mismatch!!");
						continue;
					}

				} while (true);

				break;
			case 2:
				service2 = new ComposerService();
				userservice = new UserActionService();
				ArrayList<ComposerBean> list2 = service2.getAllComposerID();
				System.out.println();
				System.out.println("Here is the list of Composer ID-->");
				for (ComposerBean l : list2) {
					System.out.println("ID: " + l.getComposer_id() + "  Name: "
							+ l.getComposer_name());
				}
				System.out.println();
				do {
					try {
						Scanner sc2 = new Scanner(System.in);
						System.out.println("Enter Composer ID:");
						long composerid = sc2.nextLong();
						int check1 = service2.checkComposer(composerid);
						if (check1 == 0) {
							System.err.println("Invalid Composer ID");
							continue;
						} else {
							ArrayList<SongBean> songList = new ArrayList<>();
							songList = userservice
									.getSongByComposer(composerid);
							if (songList.isEmpty()) {
								System.err
										.println("No song found for Composer ID: "
												+ composerid);
								break;
							} else {
								System.out.println();
								System.out.println();
								System.out.println("List of Songs -->");
								System.out.println();
								System.out.println();
								for (SongBean song : songList) {
									/*
									 * System.out.println("Composer ID: " +
									 * composerid);
									 */
									System.out.print("-->>Song ID: "
											+ song.getSongID());
									System.out.print("| Song Name: "
											+ song.getSongName());
									System.out.println("| Song Duration: "
											+ song.getSong_duration());
									/*
									 * System.out.print(" Created By: " +
									 * song.getCreatedBY());
									 * System.out.println(" Creted On: " +
									 * song.getCreatedOn());
									 * System.out.print(" Updated By: " +
									 * song.getUpdatedBY());
									 * System.out.println(" Updated On: " +
									 * song.getUpdatedOn());
									 */
									System.out.println();
									System.out.println();
								}
								break;
							}

						}
					} catch (InputMismatchException e) {
						System.err.println("Wrong Input Pattern!!");
						continue;
					}
				} while (true);

				break;
			case 3:
				System.out.println("Application Terminated");
				System.exit(0);
			default:
				System.err.println("Wrong Choice!!");
				userAction(userID);
				break;
			}

			do {
				BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
				System.out
						.println("Do you want to continue?? Press Y to continue and N to Exit");
				ch = br.readLine();
				if (ch.equals("Y") || ch.equals("y") || ch.equals("N")
						|| ch.equals("n"))
					break;
				else
					System.err.println("Wrong Input");

			} while (true);

		} while (ch.equals("y") || ch.equals("Y"));
		System.out.println("Application Terminated");
		System.exit(0);
	}

	/*
	 * 
	 * Admin action menu
	 * Admin can manipulate existing database by selecting from the menu given here
	 * 
	 */
	public static void adminAction(long creatorID)
			throws MediaComposerException, IOException {
		Scanner sc = new Scanner(System.in);
		String ch = "Y";
		do {
			try {
				System.out.println("Choose Your Action:");
				System.out.println("1. Artist Access");
				System.out.println("2. Composer Access");
				System.out.println("3. Song Artist Association Access");
				System.out.println("4. Song Composer Association Access");
				System.out.println("5. View All Songs Details");
				System.out.println("6. User Access");
				System.out.println("7. Exit");
				System.out.println("Enter Option:");
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					adminArtistAction(creatorID);

					break;
				case 2:
					adminComposerAction(creatorID);
					break;
				case 3:
					adminSongArtistAssocAction(creatorID);
					break;
				case 4:
					adminSongComposerAssocAction(creatorID);
				case 5:
					adminViewAllSong(creatorID);
					break;
				case 6:
					adminUserAction(creatorID);
					break;
				case 7:
					System.out.println("Application Terminated");
					System.exit(0);
					break;
				default:
					System.out.println("Wrong Choice");
					break;

				}

				System.out
						.println("Do you want to continue?? Press Y to continue");
				ch = sc.next();
			} catch (InputMismatchException e) {
				System.err.println("Wrong Input Pattern!!  ");
				logger.error("Wrong Input Pattern!!");
				adminAction(creatorID);
			}

		} while (ch.equals("Y") || ch.equals("y"));
		adminAction(creatorID);

	}

	/*
	 * 
	 * This method display all songs available in the database to the admin
	 * 
	 */

	public static void adminViewAllSong(long creatorID)
			throws MediaComposerException, IOException {
		ArrayList<SongBean> songList = new ArrayList<>();
		service4 = new SongService();
		songList = service4.viewAllSong();
		System.out.println();
		System.out.println();
		System.out.println("List of Songs-->");
		System.out.println();
		System.out.println();
		if (songList.isEmpty())
			System.err.println("No song found!!");
		else {
			for (SongBean song : songList) {
				System.out.print("Song ID: " + song.getSongID());
				System.out.print(" | Song Name: " + song.getSongName());
				System.out
						.print(" | Song Duration: " + song.getSong_duration());
				System.out.println();
				System.out.println();
			}
		}
		adminAction(creatorID);
	}
	
	
	/*
	 * 
	 * This method is used by Admin to map a Song ID with an Artist ID
	 * Data is stored in Artist_Song_Assoc Table in the Database 
	 * 
	 */
	
	

	public static void adminSongArtistAssocAction(long creatorID)
			throws MediaComposerException, IOException {
		service1 = new ArtistService();
		service4 = new SongService();
		Scanner sc = new Scanner(System.in);
		service3 = new SongAssocService();
		ArrayList<ArtistBean> list1 = service1.getAllArtistID();
		System.out.println("Here is the list of Artist ID-->");
		for (ArtistBean l : list1) {
			System.out.print(l.getArtist_id() + "  ");
		}
		System.out.println();
		String ch = "Y";
		do {
			try {

				System.out.println("Enter Artist ID");
				long artistid = sc.nextLong();
				int n2 = service1.checkArtist(artistid);
				if (n2 == 0)
					System.err.println("Invalid Artist ID");
				else {
					ArrayList<Long> list6 = service4.getAllSongID();
					System.out.println("Here is the list of Song ID-->");
					for (Long l : list6) {
						System.out.print(l + "  ");
					}
					System.out.println();
					long songid = 0;
					do {
						Scanner sc10 = new Scanner(System.in);
						try {
							System.out.println("Enter Song ID");
							songid = sc10.nextLong();
							if (service4.checkSong(songid) == 1)
								break;
							else {
								System.err.println("Invalid Song ID");
								continue;
							}
						} catch (InputMismatchException e) {
							System.err.println("Invalid Input pattern!!");
							logger.error("Invalid Input Pattern!!");
							continue;
						}
					} while (true);

					int n = service3.addSongArtistAssoc(songid, artistid,
							creatorID);
					/*
					 * if (n == 0) System.out.println("Invalid Artist ID");
					 */
					if (n == -1)

						System.err.println("Invalid Song ID");
					else {
						System.out.println(n + " record inserted");
						logger.info(n
								+ " record inserted in Artist_Song_Assoc Table");
					}
					do {
						System.out
								.println("Do you want to continue?? Press Y to continue and N to go back");
						ch = scanner.next();
						if (ch.equals("Y") || ch.equals("y") || ch.equals("N")
								|| ch.equals("n"))
							break;
						else
							System.err.println("Wrong Input");

					} while (true);

				}

			} catch (InputMismatchException e) {
				System.err.println("Wrong Input Pattern!!  ");
				logger.error("Wrong Input Pattern");
				adminSongArtistAssocAction(creatorID);
			}

		} while (ch.equals("Y") || ch.equals("y"));
		adminAction(creatorID);

	}

	/*
	 * 
	 * This method is used by Admin to map a Song ID with an Composer ID
	 * Data is stored in Composer_Song_Assoc Table in the Database
	 * 
	 */

	public static void adminSongComposerAssocAction(long creatorID)
			throws MediaComposerException, IOException {
		service2 = new ComposerService();
		Scanner sc = new Scanner(System.in);
		service3 = new SongAssocService();
		service4 = new SongService();
		String ch = "Y";
		ArrayList<ComposerBean> list2 = service2.getAllComposerID();
		System.out.println("Here is the list of Composer ID-->");
		for (ComposerBean l : list2) {
			System.out.print(l.getComposer_id() + "  ");
		}

		System.out.println();
		do {
			try {

				System.out.println("Enter Composer ID");
				long composerid = sc.nextLong();
				int n2 = service2.checkComposer(composerid);
				if (n2 == 0)
					System.err.println("Invalid Composer ID");
				else {
					ArrayList<Long> list6 = service4.getAllSongID();
					System.out.println("Here is the list of Song ID-->");
					for (Long l : list6) {
						System.out.print(l + "  ");
					}
					System.out.println();
					long songid = 0;
					do {
						Scanner sc10 = new Scanner(System.in);
						try {
							System.out.println("Enter Song ID");
							songid = sc10.nextLong();
							if (service4.checkSong(songid) == 1)
								break;
							else {
								System.err.println("Invalid Song ID");
								continue;
							}
						} catch (InputMismatchException e) {
							System.err.println("Invalid Input pattern!!");
							continue;
						}
					} while (true);
					int n = service3.addSongComposerAssoc(songid, composerid,
							creatorID);
					/*
					 * if (n == 0) System.out.println("Invalid Composer ID");
					 */
					if (n == -1)
						System.err.println("Invalid Song ID");
					else {
						System.out.println(n + " record inserted");
						logger.info(n
								+ " record inserted in Composer_Song_Assoc Table");
					}

					do {
						System.out
								.println("Do you want to continue?? Press Y to continue and N to go back");
						ch = scanner.next();
						if (ch.equals("Y") || ch.equals("y") || ch.equals("N")
								|| ch.equals("n"))
							break;
						else
							System.err.println("Wrong Input");

					} while (true);
				}

			} catch (InputMismatchException e) {
				System.err.println("Wrong Input Pattern!!  ");
				logger.error("Wrong Input Pattern");
				adminSongComposerAssocAction(creatorID);
			}
		} while (ch.equals("Y") || ch.equals("y"));
		adminAction(creatorID);
	}

	/*
	 * 
	 * Admin action related to Composer
	 * Admin can Insert, Delete, Update, Search and View all Composer details
	 * Data is stored in Composer_Master table in the database
	 * 
	 */

	public static void adminComposerAction(long creatorID)
			throws MediaComposerException, IOException {
		Scanner sc = new Scanner(System.in);
		service2 = new ComposerService();
		service4 = new SongService();
		int n = 0;
		/*
		 * ArrayList<ComposerBean> list2 = service2.getAllComposerID();
		 * System.out.println("Here is the list of Composer ID-->"); for
		 * (ComposerBean l : list2) { System.out.print(l.getComposer_id()+"  ");
		 * } System.out.println();
		 */
		ComposerBean composer = null;
		String ch = "Y";

		do {

			try {

				System.out.println("Choose your action");
				System.out.println("1. Create Composer");
				System.out.println("2. Delete Composer");
				System.out.println("3. Update Composer");
				System.out.println("4. Search Composer");
				System.out.println("5. View All Composer");
				System.out.println("6: Exit");
				System.out.println("7: Back");
				System.out.println("Enter Option:");
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					String composerName=null;
					do{
						BufferedReader br2 = new BufferedReader(
								new InputStreamReader(System.in));
						System.out.println("Enter Composer name: ");
						composerName = br2.readLine();
						Pattern namePattern = Pattern.compile("^[A-Za-z\\s]{1,30}$");
						Matcher nameMatcher = namePattern.matcher(composerName);
						if(composerName.equals("")){
							System.err.println("Composer Name cannot be blank!");
							continue;
							
						}
						else if(!nameMatcher.matches()){
							System.err.println("Composer Name should not contain Number!!");
							continue;
						}
						else
							break;
					}while(true);
					
					Date composerBornDate = null;
					do {
						try {
							System.out
									.println("Enter composer born date (yyyy-mm-dd): ");

							String composerBDate = sc.next();
							if (isValidDate(composerBDate)) {
								composerBornDate = Date.valueOf(composerBDate);
								if (composerBornDate.before(Date
										.valueOf(LocalDate.now())))
									break;
								else {
									System.err
											.println("Born Date cannot be greater than Died date!!");
									continue;
								}
							} else {
								System.err.println("Invalid Date Format!!! ");
								// adminComposerAction(creatorID);
							}
						} catch (IllegalArgumentException e) {
							System.err.println("Invalid date format");
							logger.error("Invalid Date Format!!");
							// adminComposerAction(creatorID);
							continue;
						}
					} while (true);
					Date composerDiedDate = null;
					do {
						try {
							BufferedReader br7 = new BufferedReader(
									new InputStreamReader(System.in));
							System.out
									.println("Enter composer died date (yyyy-mm-dd)(You can skip this field, Died date will be set to null): ");

							String composerDate = br7.readLine();
							if (composerDate.equals(""))
								break;
							if (!composerDate.equals("")) {
								if (isValidDate(composerDate)) {
									composerDiedDate = Date
											.valueOf(composerDate);
									if (composerDiedDate
											.after(composerBornDate)
											&& composerDiedDate.before(Date
													.valueOf(LocalDate.now())))
										break;
									else {
										System.err
												.println("Died Date cannot be lower than Born date or greater than Died date!!");
										continue;
									}
								} else {
									System.err
											.println("Invalid Date Format!!! ");
									// adminComposerAction(creatorID);
								}
							}
						} catch (IllegalArgumentException e) {
							System.err.println("Invalid date format");
							logger.error("Invalid Date Format!!");
							// adminComposerAction(creatorID);
							continue;
						}
					} while (true);
					System.out.println("Enter Composer Caeipi Number: ");
					String caeipi = sc.next();
					String mSociety = null;
					do {
						Scanner sc22 = new Scanner(System.in);
						System.out
								.println("Enter Composer Music Society ID('ABC'/'XYZ'): ");
						mSociety = sc22.next();
						if (mSociety.toUpperCase().equals("ABC")
								|| mSociety.toUpperCase().equals("XYZ")) {
							break;
						} else {
							System.err
									.println("Enter Mosic Society ID from given options");
							continue;
						}
					} while (true);

					/*
					 * if (!(mSociety.equals("ABC") || mSociety.equals("XYZ")))
					 * mSociety = null;
					 */
					composer = new ComposerBean(composerName, composerBornDate,
							composerDiedDate, caeipi, mSociety);
					long l = service2.addComposer(composer, creatorID);
					if (l != 0 && l != -1) {
						System.out.print(" Composer added");
						System.out.println(" for Composer ID " + l);
						logger.info(" Composer Added");
					}
					break;
				case 2:
					ArrayList<ComposerBean> list7 = service2.getAllComposerID();
					System.out.println("Here is the list of Composer ID-->");
					for (ComposerBean l1 : list7) {
						System.out.print(l1.getComposer_id() + "  ");
					}
					System.out.println();
					long composerid = 0;
					do {
						Scanner sc4 = new Scanner(System.in);
						try {
							System.out
									.println("Enter Composer ID to be deleted");
							composerid = sc4.nextLong();
							break;
						} catch (InputMismatchException e) {
							System.err.println("Invalid Input Pattern");
							continue;
						}
					} while (true);

					n = service2.deleteComposer(composerid);
					if (n == 0)
						System.err.println("No record found for Composer ID "
								+ composerid);
					else
						System.out.println(n + " record deleted");
					logger.info(n + " Composer Deleted");
					break;
				case 3:
					ArrayList<ComposerBean> list21 = service2
							.getAllComposerID();
					System.out.println("Here is the list of Composer ID-->");
					for (ComposerBean l2 : list21) {
						System.out.print(l2.getComposer_id() + "  ");
					}
					System.out.println();
					do {
						Scanner sc5 = new Scanner(System.in);
						try {
							System.out
									.println("Enter Composer ID to be updated");
							composerid = sc5.nextLong();
							break;
						} catch (InputMismatchException e) {
							System.err.println("Invalid Input Pattern");
							continue;
						}
					} while (true);
					int check = service2.checkComposer(composerid);
					if (check == 0)
						System.err.println("Composer ID not Found!!");
					else {
						ComposerBean cmpsr = new ComposerBean();
						cmpsr = service2.searchComposer(composerid);
						System.out.println("Composer Name: "
								+ cmpsr.getComposer_name()
								+ " Composer Caeipi Number: "
								+ cmpsr.getComposer_caeipiNumber()
								+ " Composer Music Society ID: "
								+ cmpsr.getComposer_musicsocietyid()
								+ " Composer Born Date: "
								+ cmpsr.getComposer_borndate()
								+ " Composer Died Date: "
								+ cmpsr.getComposer_dieddate());
						System.out.println();
						System.out.println();

						System.out.println("1. Update Composer Name");
						System.out.println("2. Update Caeipi Number");
						System.out.println("3. Update Music Society ID");
						System.out.println("4. Update Composer Born Date");
						System.out.println("5. Update Composer Died Date");
						System.out.println("Enter your choice");
						ComposerBean composer5 = null;
						int n2 = 0;
						int choice1 = sc.nextInt();
						switch (choice1) {
						case 1:
							String composername=null;
							do{
								BufferedReader br3 = new BufferedReader(
										new InputStreamReader(System.in));
								System.out.println("Enter composer name: ");
								composername = br3.readLine();
								Pattern namePattern = Pattern.compile("[A-Za-z\\s]{1,30}");
								Matcher nameMatcher = namePattern.matcher(composername);
								if(composername.equals("")){
									System.err.println("Composer Name cannot be blank!");
									continue;
									
								}
								else if(!nameMatcher.matches()){
									System.err.println("Artist Name should not contain Number!");
									continue;
								}
								else
									break;
							}while(true);
							/*BufferedReader br3 = new BufferedReader(
									new InputStreamReader(System.in));
							
							System.out.println("Enter new Composer Name");
							String composername = br3.readLine();*/
							composer5 = new ComposerBean();
							composer5.setComposer_id(composerid);
							composer5.setComposer_name(composername);
							n2 = service2.updateComposer(composer5, creatorID,
									1);
							if (n2 == 0)
								System.err
										.println("Record not found for Composer ID: "
												+ composer5.getComposer_id());
							else
								System.out.println(n2
										+ " Record updated for Composer ID: "
										+ composer5.getComposer_id());
							break;
						case 2:
							composer5 = new ComposerBean();
							System.out
									.println("Enter new Composer Caeipi Number");
							String caeipinumber = sc.next();
							composer5.setComposer_id(composerid);
							composer5.setComposer_caeipiNumber(caeipinumber);
							n2 = service2.updateComposer(composer5, creatorID,
									2);
							if (n2 == 0)
								System.err
										.println("Record not found for Composer ID: "
												+ composer5.getComposer_id());
							else
								System.out.println(n2
										+ " Record updated for Composer ID: "
										+ composer5.getComposer_id());
							break;
						case 3:
							composer5 = new ComposerBean();
							String mSociety1 = null;
							do {
								Scanner sc21 = new Scanner(System.in);
								System.out
										.println("Enter new Composer Music Society ID('ABC'/'XYZ'): ");
								mSociety1 = sc21.next();
								if (mSociety1.toUpperCase().equals("ABC")
										|| mSociety1.toUpperCase()
												.equals("XYZ")) {
									break;
								} else {
									System.err
											.println("Enter Mosic Society ID from given options");
									continue;
								}
							} while (true);
							/*
							 * if (!(mSociety1.equals("ABC") ||
							 * mSociety1.equals("XYZ"))) mSociety1 = null;
							 */
							composer5.setComposer_id(composerid);
							composer5.setComposer_musicsocietyid(mSociety1);
							n2 = service2.updateComposer(composer5, creatorID,
									3);
							if (n2 == 0)
								System.err
										.println("Record not found for Composer ID: "
												+ composer5.getComposer_id());
							else
								System.out.println(n2
										+ " Record updated for Composer ID: "
										+ composer5.getComposer_id());
							break;
						case 4:

							do {
								Scanner sc22 = new Scanner(System.in);
								Date bornDate = null;
								try {
									composer5 = new ComposerBean();
									System.out
											.println("Enter new composer Born Date(yyyy-mm-dd)");
									String bDate = sc22.next();

									if (isValidDate(bDate)) {
										int flag1 = 0;
										bornDate = Date.valueOf(bDate);
										if (!bornDate.before(Date
												.valueOf(LocalDate.now())))
										// break;
										{
											System.err
													.println("Born date cannot be greater than current date!!");
											// continue;
											flag1 = 1;
										}
										/*
										 * if(flag1==1) throw new
										 * MediaComposerException();
										 */
										else {
											composer5
													.setComposer_id(composerid);
											composer5
													.setComposer_borndate(bornDate);
											n2 = service2.updateComposer(
													composer5, creatorID, 4);
											if (n2 == -1) {
												System.out
														.println("Born date cannot be greater then current date");
												// break;
											} else if (n2 == 0)
												System.out
														.println("Record not found for Composer ID: "
																+ composer5
																		.getComposer_id());
											else
												System.out
														.println(n2
																+ " Record updated for Composer ID: "
																+ composer5
																		.getComposer_id());
											break;
										}

									} else {
										System.out
												.println("Invalid Date Format!!! ");
										continue;
										// adminComposerAction(creatorID);
									}

								} catch (IllegalArgumentException e) {
									System.out.println("Invalid date format");
									logger.error("Invalid Date Format!!");
									// adminComposerAction(creatorID);
									continue;
								} /*
								 * catch (MediaComposerException e) { // TODO
								 * Auto-generated catch block
								 * //e.printStackTrace(); continue; }
								 */

							} while (true);
							break;
						case 5:
							int flag = 0;
							do {
								// Scanner sc23=new Scanner(System.in);
								BufferedReader br8 = new BufferedReader(
										new InputStreamReader(System.in));
								Date diedDate = null;
								try {
									composer5 = new ComposerBean();
									System.out
											.println("Enter new composer Died Date(yyyy-mm-dd)(You can skip this field, Died date will be set to null)");
									String dDate = br8.readLine();
									if (dDate.equals("")) {
										composer5.setComposer_id(composerid);
										composer5
												.setComposer_dieddate(diedDate);
										flag = 1;
										n2 = service2.updateComposer(composer5,
												creatorID, 5);
										if (n2 == -1) {
											System.out
													.println("Born date cannot be greater then current date");
											// break;
										} else if (n2 == 0)
											System.out
													.println("Record not found for Composer ID: "
															+ composer5
																	.getComposer_id());
										else
											System.out
													.println(n2
															+ " Record updated for Composer ID: "
															+ composer5
																	.getComposer_id());
										break;
									}
									if (flag == 0) {
										if (isValidDate(dDate)) {
											diedDate = Date.valueOf(dDate);
											if (!(diedDate.before(Date
													.valueOf(LocalDate.now())))) {
												System.err
														.println("Died date cannot be greater than current date!!");
											} 
											else if(diedDate.before(cmpsr.getComposer_borndate())){
												System.err
														.println("Died Date cannot be lower than born date!!");
											}
											else {
												composer5
														.setComposer_id(composerid);
												composer5
														.setComposer_dieddate(diedDate);
												n2 = service2
														.updateComposer(
																composer5,
																creatorID, 5);
												if (n2 == 0)
													System.out
															.println("Record not found for Composer ID: "
																	+ composer5
																			.getComposer_id());
												else
													System.out
															.println(n2
																	+ " Record updated for Composer ID: "
																	+ composer5
																			.getComposer_id());
												break;
											}

										} else {
											System.out
													.println("Invalid Date Format!!! ");
											continue;
											// adminComposerAction(creatorID);
										}
									}

								} catch (IllegalArgumentException e) {
									System.out.println("Invalid date format");
									logger.error("Invalid Date Format!!");
									// adminComposerAction(creatorID);
									continue;
								}

							} while (flag == 0);
							break;
						default:
							System.out.println("Wrong Choice");
							break;
						}

					}

					break;
				case 4:
					ArrayList<ComposerBean> list22 = service2
							.getAllComposerID();
					System.out.println("Here is the list of Composer ID-->");
					for (ComposerBean l3 : list22) {
						System.out.print(l3.getComposer_id() + "  ");
					}
					System.out.println();
					do {
						Scanner sc11 = new Scanner(System.in);
						try {
							System.out
									.println("Enter Composer ID to be Searched");
							composerid = sc11.nextLong();
							break;
						} catch (InputMismatchException e) {
							System.out.println("Invalid Input pattern!!");
							continue;
						}
					} while (true);

					ComposerBean composer1 = service2
							.searchComposer(composerid);
					if (composer1 == null)
						System.out.println("No Record Found for Composer ID "
								+ composerid);
					else {
						System.out.print("--> Composer ID: " + composerid);
						System.out.println("  Composer Name: "
								+ composer1.getComposer_name());
						System.out.print(" Born Date: "
								+ composer1.getComposer_borndate());
						System.out.println(" Died Date: "
								+ composer1.getComposer_dieddate());
						System.out.print(" Caeipi Number: "
								+ composer1.getComposer_caeipiNumber());
						System.out.println("  Music Society ID: "
								+ composer1.getComposer_musicsocietyid());
						System.out.print("  Created By: "
								+ composer1.getCreated_by());
						System.out.println("  Created On: "
								+ composer1.getCreated_on());
						System.out.print("  Updated By: "
								+ composer1.getUpdated_by());
						System.out.println("  Updated On: "
								+ composer1.getUpdated_on());
						System.out.println(" Deleted Flag: "
								+ composer1.getComposer_deletedflag());
						System.out.println();
						System.out.println();
					}
					break;
				case 5:
					ArrayList<ComposerBean> composerList = service2
							.viewAllComposer();
					int i = 0;
					if (composerList.isEmpty())
						System.out.println("No Record Found!!");
					else
						for (ComposerBean composer2 : composerList) {
							i++;
							System.out.print(i + "--> Composer ID: "
									+ composer2.getComposer_id());
							System.out.println("  Composer Name: "
									+ composer2.getComposer_name());
							System.out.print(" Born Date: "
									+ composer2.getComposer_borndate());
							System.out.println(" Died Date: "
									+ composer2.getComposer_dieddate());
							System.out.print(" Caeipi Number: "
									+ composer2.getComposer_caeipiNumber());
							System.out.println(" Music Society ID: "
									+ composer2.getComposer_musicsocietyid());
							System.out.print("  Created By: "
									+ composer2.getCreated_by());
							System.out.println("  Created On: "
									+ composer2.getCreated_on());
							System.out.print("  Updated By: "
									+ composer2.getUpdated_by());
							System.out.println("  Updated On: "
									+ composer2.getUpdated_on());
							System.out.println(" Deleted Flag: "
									+ composer2.getComposer_deletedflag());
							System.out.println();
							System.out.println();

						}
					break;
				case 6:
					System.out.println("Application Terminated");
					System.exit(0);
				case 7:
					adminAction(creatorID);
					break;
				default:
					System.out.println("Wrong choice!!!");
					break;
				}

				do {
					System.out
							.println("Do you want to continue?? Press Y to continue and N to go back");
					ch = scanner.next();
					if (ch.equals("Y") || ch.equals("y") || ch.equals("N")
							|| ch.equals("n"))
						break;
					else
						System.out.println("Wrong Input");

				} while (true);

			} catch (InputMismatchException e) {

				System.out.println("Wrong Input Pattern!!  " + e);
				logger.error("Wrong Input Pattern!!");
				adminComposerAction(creatorID);
			}

		} while (ch.equals("Y") || ch.equals("y"));
		adminAction(creatorID);

	}

	/*
	 * 
	 * Admin action related to Artist
	 * Admin can Insert, Delete, Update, Search and View all Artist details
	 * Data is stored in Artist_Master table in the database
	 * 
	 */

	public static void adminArtistAction(long creatorID)
			throws MediaComposerException, IOException {
		Scanner sc = new Scanner(System.in);
		service1 = new ArtistService();
		int n = 0;
		ArtistBean artist = null;
		String ch = "Y";

		do {

			try {

				System.out.println("Choose your action");
				System.out.println("1. Create Artist");
				System.out.println("2. Delete Artist");
				System.out.println("3. Update Artist");
				System.out.println("4. Search Artist");
				System.out.println("5. View All Artist");
				System.out.println("6. Exit");
				System.out.println("7: Back");
				System.out.println("Enter Option:");
				int choice = sc.nextInt();
				long artistid;
				switch (choice) {
				case 1:
					String artistName=null;
					do{
						BufferedReader br = new BufferedReader(
								new InputStreamReader(System.in));
						System.out.println("Enter artist name: ");
						Pattern namePattern = Pattern.compile("^[A-Za-z\\s]{1,30}$");
						
						artistName = br.readLine();
						Matcher nameMatcher = namePattern.matcher(artistName);
						if(artistName.equals("")){
							System.err.println("Artist Name cannot be blank!");
							continue;
							
						}
						else if(!nameMatcher.matches()){
							System.err.println("Artist Name should not contain any number");
							continue;
						}
						else
							break;
					}while(true);
					
					String artistType = null;
					do {
						System.out.println("Enter artist type ('A'/'B'): ");
						artistType = sc.next();
						if (artistType.toUpperCase().equals("A")
								|| artistType.toUpperCase().equals("B"))
							break;
						else {
							System.out
									.println("Choose Artist Type from given option");
							continue;
						}

					} while (true);

					Date artistBornDate = null;
					do {
						try {
							System.out
									.println("Enter artist born date (yyyy-mm-dd): ");
							String artistBDate = sc.next();

							if (isValidDate(artistBDate)) {

								artistBornDate = Date.valueOf(artistBDate);
								if (artistBornDate.before(Date
										.valueOf(LocalDate.now())))
									break;
								else {
									System.out
											.println("Born Date cannot be greater than current date");
									continue;
								}
							} else {
								System.out.println("Invalid Date Format!!");
								// adminArtistAction(creatorID);
							}
						} catch (IllegalArgumentException e) {
							System.out.println("Invalid date format");
							logger.error("Invalid Date Format!!");
							// adminComposerAction(creatorID);
							continue;
						}
					} while (true);
					Date artistDiedDate = null;
					do {
						try {
							BufferedReader br5 = new BufferedReader(
									new InputStreamReader(System.in));
							System.out
									.println("Enter artist died date (yyyy-mm-dd):(You can skip this field, Died date will be set to null) ");
							String artistDate = br5.readLine();
							if (artistDate.equals(""))
								break;
							if (!artistDate.equals("")) {
								if (isValidDate(artistDate)) {
									artistDiedDate = Date.valueOf(artistDate);
									if (artistDiedDate.after(artistBornDate)
											&& artistDiedDate.before(Date
													.valueOf(LocalDate.now())))
										break;
									else {
										System.err
												.println("Died Date cannot be lower than Born date or greater than Died date!!");
										continue;
									}
								} else {
									System.out.println("Invalid Date Format!!");
									// adminArtistAction(creatorID);
								}
							}
						} catch (IllegalArgumentException e) {
							System.out.println("Invalid date format");
							logger.error("Invalid Date Format!!");
							// adminComposerAction(creatorID);
							continue;
						}
					} while (true);

					artist = new ArtistBean(artistName, artistType,
							artistBornDate, artistDiedDate);
					long l = service1.addArtist(artist, creatorID);
					if (l != -1 && l != 0) {
						System.out.print("Artist added for ");
						System.out.println("Artist ID: " + l);

						logger.info("1 Artist Added");
					}
					break;
				case 2:
					ArrayList<ArtistBean> list1 = service1.getAllArtistID();
					System.out.println("Here is the list of Artist ID-->");
					for (ArtistBean l1 : list1) {
						System.out.print(l1.getArtist_id() + "  ");
					}
					System.out.println();
					do {
						Scanner sc4 = new Scanner(System.in);
						try {
							System.out.println("Enter Artist ID to be deleted");
							artistid = sc4.nextLong();
							break;
						} catch (InputMismatchException e) {
							System.out.println("Invalid Input Pattern!!");
							continue;
						}
					} while (true);

					n = service1.deleteArtist(artistid);
					if (n == 0)
						System.out.println("No record found for Artist ID "
								+ artistid);
					else {
						System.out.println(n + " record deleted");
						logger.info(n + " Artist Deleted");
					}
					break;
				case 3:
					ArrayList<ArtistBean> list2 = service1.getAllArtistID();
					System.out.println("Here is the list of Artist ID-->");
					for (ArtistBean l2 : list2) {
						System.out.print(l2.getArtist_id() + "  ");
					}
					System.out.println();
					do {
						Scanner sc5 = new Scanner(System.in);
						try {
							System.out
									.println("Enter Artist ID to be updated:");
							artistid = sc5.nextLong();
							break;
						} catch (InputMismatchException e) {
							System.out.println("Invalid Input Pattern!!");
							continue;
						}
					} while (true);

					int check = service1.checkArtist(artistid);
					if (check == 0) {
						System.out.println("Artist ID not Found!!");
					} else {
						ArtistBean artst = new ArtistBean();
						artst = service1.searchArtist(artistid);
						System.out.println("Artist Name: "
								+ artst.getArtist_name() + " Artist Type: "
								+ artst.getArtist_type()
								+ " Artist Born Date: "
								+ artst.getArtist_borndate()
								+ " Artist Died Date: "
								+ artst.getArtist_dieddate());
						System.out.println();
						System.out.println();
						System.out.println("1. Update Artist Name");
						System.out.println("2. Update Artist Type");
						System.out.println("3. Update Artist Born Date");
						System.out.println("4. Update Artist Died Date");
						System.out.println("Enter your choice");
						ArtistBean artist5 = null;
						int n2 = 0;
						int choice1 = sc.nextInt();
						switch (choice1) {
						case 1:
							String artistname=null;
							do{
								BufferedReader br1 = new BufferedReader(
										new InputStreamReader(System.in));
								System.out.println("Enter artist name: ");
								artistname = br1.readLine();
								Pattern namePattern = Pattern.compile("^[A-Za-z\\s]{1,30}$");
								Matcher nameMatcher = namePattern.matcher(artistname);
								if(artistname.equals("")){
									System.err.println("Artist Name cannot be blank!");
									continue;
									
								}
								else if(!nameMatcher.matches()){
									System.err.println("Artist Name should not contain Number!");
									continue;
								}
								else
									break;
							}while(true);
							/*BufferedReader br1 = new BufferedReader(
									new InputStreamReader(System.in));
							
							System.out.println("Enter new Artist Name");*/
							//String artistname = br1.readLine();
							artist5 = new ArtistBean();
							artist5.setArtist_id(artistid);
							artist5.setArtist_name(artistname);
							n2 = service1.updateArtist(artist5, creatorID, 1);
							if (n2 == 0)
								System.out
										.println("Record not found for Artist ID: "
												+ artist5.getArtist_id());
							else
								System.out.println(n2
										+ " Record updated for Artist ID: "
										+ artist5.getArtist_id());
							break;
						case 2:
							artist5 = new ArtistBean();
							String artisttype = null;
							do {
								Scanner sc31 = new Scanner(System.in);
								System.out
										.println("Enter new Artist Type('A'/'B'):");
								artisttype = sc31.next();
								if (artisttype.toUpperCase().equals("A")
										|| artisttype.toUpperCase().equals("B")) {
									break;

								} else {
									System.out
											.println("Choose Artist Type from given option");
									continue;
								}
							} while (true);

							artist5.setArtist_id(artistid);
							artist5.setArtist_type(artisttype);
							n2 = service1.updateArtist(artist5, creatorID, 2);
							if (n2 == 0)
								System.out
										.println("Record not found for Artist ID: "
												+ artist5.getArtist_id());
							else
								System.out.println(n2
										+ " Record updated for Artist ID: "
										+ artist5.getArtist_id());
							break;
						case 3:
							Date bornDate = null;
							do {
								Scanner sc32 = new Scanner(System.in);
								try {
									artist5 = new ArtistBean();

									System.out
											.println("Enter new Artist Born Date(yyyy-mm-dd)");
									String bDate = sc32.next();
									if (isValidDate(bDate)) {
										bornDate = Date.valueOf(bDate);
										if (!(bornDate.before(Date
												.valueOf(LocalDate.now())))) {
											System.err
													.println("Born Date cannot be greater than current date!!");
										} else {
											artist5.setArtist_id(artistid);
											artist5.setArtist_borndate(bornDate);
											n2 = service1.updateArtist(artist5,
													creatorID, 3);
											if (n2 == -1) {
												System.out
														.println("BornDate cannot be greater than current date");
											} else if (n2 == 0)
												System.out
														.println("Record not found for Artist ID: "
																+ artist5
																		.getArtist_id());

											else
												System.out
														.println(n2
																+ " Record updated for Artist ID: "
																+ artist5
																		.getArtist_id());
											break;
										}

									} else {
										System.out
												.println("Invalid Date Format!!!");
										continue;
										// adminArtistAction(creatorID);
									}

								} catch (IllegalArgumentException e) {
									System.out.println("Invalid date format");
									logger.error("Invalid Date Format!!");
								}
							} while (true);
							break;
						case 4:
							int flag = 0;
							Date diedDate = null;
							do {
								// Scanner sc33=new Scanner(System.in);
								BufferedReader br6 = new BufferedReader(
										new InputStreamReader(System.in));
								try {
									artist5 = new ArtistBean();

									System.out
											.println("Enter new Artist Died Date(yyyy-mm-dd)(You can skip this field, Died date will be set to null)");
									String dDate = br6.readLine();
									if (dDate.equals("")) {
										artist5.setArtist_id(artistid);
										artist5.setArtist_dieddate(diedDate);
										flag = 1;
										n2 = service1.updateArtist(artist5,
												creatorID, 4);
										if (n2 == 0)
											System.out
													.println("Record not found for Artist ID: "
															+ artist5
																	.getArtist_id());
										else
											System.out
													.println(n2
															+ " Record updated for Artist ID: "
															+ artist5
																	.getArtist_id());
										break;
									}
									if (flag == 0) {
										if (isValidDate(dDate)) {
											diedDate = Date.valueOf(dDate);
											if (!(diedDate.before(Date
													.valueOf(LocalDate.now())))) {
												System.err
														.println("Died date cannot be greater than current date!!");
											}
											else if(diedDate.before(artst.getArtist_borndate())){
												System.err
														.println("Died Date cannot be lower than born date!!");
											}
											else {
												artist5.setArtist_id(artistid);
												artist5.setArtist_dieddate(diedDate);
												n2 = service1.updateArtist(
														artist5, creatorID, 4);
												if (n2 == -1) {
													System.out
															.println("DiedDate cannot be greater than current date");
												} else if (n2 == 0)
													System.out
															.println("Record not found for Artist ID: "
																	+ artist5
																			.getArtist_id());
												else
													System.out
															.println(n2
																	+ " Record updated for Artist ID: "
																	+ artist5
																			.getArtist_id());
												break;
											}

										} else {
											System.out
													.println("Invalid Date Format!!!");
											continue;
											// adminArtistAction(creatorID);
										}
									}
								} catch (IllegalArgumentException e) {
									System.out.println("Invalid date format");
									logger.error("Invalid Date Format!!");
								}
							} while (true);
							break;
						default:
							System.out.println("Wrong Choice");
							break;
						}
					}

					break;
				case 4:
					ArrayList<ArtistBean> list3 = service1.getAllArtistID();
					System.out.println("Here is the list of Artist ID-->");
					for (ArtistBean l3 : list3) {
						System.out.print(l3.getArtist_id() + "  ");
					}
					System.out.println();
					do {
						Scanner sc11 = new Scanner(System.in);
						try {
							System.out
									.println("Enter Artist ID to be Searched");
							artistid = sc11.nextLong();
							break;
						} catch (InputMismatchException e) {
							System.out.println("Invalid Input Pattern!!");
							continue;
						}
					} while (true);

					ArtistBean artist1 = service1.searchArtist(artistid);
					if (artist1 == null)
						System.out.println("No Record Found for Artist ID "
								+ artistid);
					else {
						System.out.print("--> Artist ID: " + artistid);
						System.out.print("  Artist Name: "
								+ artist1.getArtist_name());
						System.out.println("  Artist Type: "
								+ artist1.getArtist_type());
						System.out.print(" Born Date: "
								+ artist1.getArtist_borndate());
						System.out.println(" Died Date: "
								+ artist1.getArtist_dieddate());
						System.out.print("  Created By: "
								+ artist1.getCreated_by());
						System.out.println("  Created On: "
								+ artist1.getCreated_on());
						System.out.print("  Updated By: "
								+ artist1.getUpdated_by());
						System.out.println("  Updated On: "
								+ artist1.getUpdated_on());
						System.out.println(" Deleted Flag: "
								+ artist1.getArtist_deletedflag());
						System.out.println();
						System.out.println();
					}
					break;
				case 5:
					ArrayList<ArtistBean> artistList = service1.viewAllArtist();
					int i = 0;
					if (artistList.isEmpty())
						System.out.println("No Record Found!!");
					else
						for (ArtistBean artist2 : artistList) {
							i++;
							System.out.print(i + "--> Artist ID: "
									+ artist2.getArtist_id());
							System.out.print("  Artist Name: "
									+ artist2.getArtist_name());
							System.out.println("  Artist Type: "
									+ artist2.getArtist_type());
							System.out.print(" Born Date: "
									+ artist2.getArtist_borndate());
							System.out.println(" Died Date: "
									+ artist2.getArtist_dieddate());
							System.out.print("  Created By: "
									+ artist2.getCreated_by());
							System.out.println("  Created On: "
									+ artist2.getCreated_on());
							System.out.print("  Updated By: "
									+ artist2.getUpdated_by());
							System.out.println("  Updated On: "
									+ artist2.getUpdated_on());
							System.out.println(" Deleted Flag: "
									+ artist2.getArtist_deletedflag());
							System.out.println();
							System.out.println();

						}
					break;
				case 6:
					System.out.println("Application Terminated");
					System.exit(0);
				case 7:
					adminAction(creatorID);
					break;
				default:
					System.out.println("Wrong choice!!!");
					break;
				}

				do {
					System.out
							.println("Do you want to continue?? Press Y to continue and N to go back");
					ch = scanner.next();
					if (ch.equals("Y") || ch.equals("y") || ch.equals("N")
							|| ch.equals("n"))
						break;
					else
						System.out.println("Wrong Input");

				} while (true);

			} catch (InputMismatchException e) {
				System.out.println("Invalid Input Pattern!!   ");
				logger.error("Wrong Input Pattern!!");
				adminArtistAction(creatorID);
			} catch (IllegalArgumentException e) {
				System.out.println("Invalid date format");
				logger.error("Invalid Date Format");
				adminArtistAction(creatorID);
			}

		} while (ch.equals("Y") || ch.equals("y"));
		adminAction(creatorID);

	}

	/*
	 * 
	 * Admin action related to User
	 * Admin can Insert, Delete, Update, Search and View all User details
	 * Data is stored in User_Master table in the database
	 * 
	 * 
	 */

	public static void adminUserAction(long creatorID)
			throws MediaComposerException, IOException {
		Scanner sc = new Scanner(System.in);
		service = new UserService();
		String ch = "Y";
		long userid = 0;
		int n = 0;
		String password = "";
		do {
			try {

				System.out.println("Choose your action");
				System.out.println("1. Create Admin");
				System.out.println("2. Create User");
				System.out.println("3. Delete User");
				System.out.println("4. Update User Password");
				System.out.println("5. Search User");
				System.out.println("6. View All User");
				System.out.println("7. Exit");
				System.out.println("8: Back");
				System.out.println("Enter Option:");
				UserBean user = null;
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					System.out.println("Enter User ID for new Admin");
					userid = sc.nextLong();
					System.out.println("Enter Password for new Admin");
					password = sc.next();
					user = new UserBean(userid, password, "A");
					n = service.addUser(user, creatorID);
					if (n == 0)
						System.out
								.println("Duplicate User ID found!! Please try other User ID");
					else {
						System.out.println(n + " Admin added");
						logger.info(n + " Admin added");
					}
					break;
				case 2:
					System.out.println("Enter User ID for new User");
					userid = sc.nextLong();
					System.out.println("Enter Password for new User");
					password = sc.next();
					user = new UserBean(userid, password, "U");
					n = service.addUser(user, creatorID);
					if (n == 0)
						System.out
								.println("Duplicate User ID found!! Please try other User ID");
					else {
						System.out.println(n + " User added");
						logger.info(n + " User Added");
					}
					break;
				case 3:

					System.out.println("Enter User ID to be deleted");
					userid = sc.nextLong();
					n = service.deleteUser(userid);
					if (n == -1)
						System.out.println("You cannot delete Admin");
					else if (n == 0)
						System.out.println("No record found for this User ID");
					else {
						System.out.println(n + " Record deleted for User ID "
								+ userid);
						logger.info(n + " User Deleted");
					}
					break;
				case 4:
					System.out.println("Enter User ID to be Updated");
					userid = sc.nextLong();
					System.out.println("Enter new password for user ID: "
							+ userid);
					password = sc.next();
					n = service.updateUserPassword(userid, password, creatorID);
					if (n == -1)
						System.out.println("You cannot update Admin");
					else if (n == 0)
						System.out.println("No record found for this User ID");
					else
						System.out.println(n + " Record updated for User ID "
								+ userid);
					break;
				case 5:
					do {
						Scanner sc11 = new Scanner(System.in);
						try {
							System.out.println("Enter User ID to be Searched");
							userid = sc.nextLong();
							break;
						} catch (InputMismatchException e) {
							System.out.println("Invalid Input Pattern!!");
							continue;
						}
					} while (true);

					UserBean user1 = service.searchUser(userid);
					if (user1 == null)
						System.out.println("No Record Found for UserID "
								+ userid);
					else {
						System.out.println("User ID:" + user1.getUser_id());
						/*
						 * System.out.println("User Password:" +
						 * user1.getUser_password());
						 */
						System.out.println("Created By:"
								+ user1.getCreated_by());
						System.out.println("Created On:"
								+ user1.getCreated_on());
						System.out.println("Updated By:"
								+ user1.getUpdated_by());
						System.out.println("Updated On:"
								+ user1.getUpdated_on());
						System.out.println("User Type:" + user1.getUser_type());
					}
					break;
				case 6:
					ArrayList<UserBean> userList = service.viewAllUser();
					int i = 0;
					if (userList.isEmpty())
						System.out.println("No Record Found!!");
					else
						for (UserBean user2 : userList) {
							i++;
							System.out.print(i + "--> User ID: "
									+ user2.getUser_id());
							/*
							 * System.out.print("  User Password: " +
							 * user2.getUser_password());
							 */
							System.out.println("  User Type: "
									+ user2.getUser_type());
							System.out.print("  Created By: "
									+ user2.getCreated_by());
							System.out.println("  Created On: "
									+ user2.getCreated_on());
							System.out.print("  Updated By: "
									+ user2.getUpdated_by());
							System.out.println("  Updated On: "
									+ user2.getUpdated_on());
							System.out.println();
							System.out.println();

						}
					break;
				case 7:
					System.out.println("Application Terminated");
					System.exit(0);
				case 8:
					adminAction(creatorID);
					break;
				default:
					System.out.println("Wrong choice!!!");
					break;
				}

				do {
					System.out
							.println("Do you want to continue?? Press Y to continue and N to go back");
					ch = scanner.next();
					if (ch.equals("Y") || ch.equals("y") || ch.equals("N")
							|| ch.equals("n"))
						break;
					else
						System.out.println("Wrong Input");

				} while (true);

			} catch (InputMismatchException e) {
				System.out.println("Invalid Input Pattern!!  ");
				logger.error("Wrong Input Pattern!!");
				adminUserAction(creatorID);
			}

		} while (ch.equals("Y") || ch.equals("y"));
		adminAction(creatorID);
	}

}
