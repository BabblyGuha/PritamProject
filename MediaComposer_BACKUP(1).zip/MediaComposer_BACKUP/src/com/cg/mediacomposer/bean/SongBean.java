package com.cg.mediacomposer.bean;

import java.sql.Date;
import java.sql.Timestamp;

import oracle.sql.TIMESTAMP;

public class SongBean {
	private long songID;
	private String songName;
	private long createdBY;
	private Date createdOn;
	private long updatedBY;
	private Date updatedOn;
	private String song_duration;
	public long getSongID() {
		return songID;
	}

	public void setSongID(long songID) {
		this.songID = songID;
	}

	public String getSongName() {
		return songName;
	}

	public void setSongName(String songName) {
		this.songName = songName;
	}

	public long getCreatedBY() {
		return createdBY;
	}

	public void setCreatedBY(long createdBY) {
		this.createdBY = createdBY;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public long getUpdatedBY() {
		return updatedBY;
	}

	public void setUpdatedBY(long updatedBY) {
		this.updatedBY = updatedBY;
	}

	public Date getUpdatedOn() {
		return updatedOn;
	}

	public void setUpdatedOn(Date updatedOn) {
		this.updatedOn = updatedOn;
	}

	public SongBean(long songID, String songName, long createdBY,
			Date createdOn, long updatedBY, Date updatedOn) {
		super();
		this.songID = songID;
		this.songName = songName;
		this.createdBY = createdBY;
		this.createdOn = createdOn;
		this.updatedBY = updatedBY;
		this.updatedOn = updatedOn;
	}

	public SongBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getSong_duration() {
		return song_duration;
	}

	public void setSong_duration(String song_duration) {
		this.song_duration = song_duration;
	}

}
