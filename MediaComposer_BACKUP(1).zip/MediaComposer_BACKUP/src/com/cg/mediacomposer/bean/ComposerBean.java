package com.cg.mediacomposer.bean;

import java.sql.Date;

public class ComposerBean {
	private long composer_id;
	private String composer_name;
	private Date composer_borndate;
	private Date composer_dieddate;
	private String composer_caeipiNumber;
	private String composer_musicsocietyid;
	private long created_by;
	private Date created_on;
	private long updated_by;
	private Date updated_on;
	private String composer_deletedflag;

	public String getComposer_name() {
		return composer_name;
	}

	public void setComposer_name(String composer_name) {
		this.composer_name = composer_name;
	}

	public Date getComposer_borndate() {
		return composer_borndate;
	}

	public void setComposer_borndate(Date composer_borndate) {
		this.composer_borndate = composer_borndate;
	}

	public Date getComposer_dieddate() {
		return composer_dieddate;
	}

	public void setComposer_dieddate(Date composer_dieddate) {
		this.composer_dieddate = composer_dieddate;
	}

	public String getComposer_caeipiNumber() {
		return composer_caeipiNumber;
	}

	public void setComposer_caeipiNumber(String composer_caeipiNumber) {
		this.composer_caeipiNumber = composer_caeipiNumber;
	}

	public String getComposer_musicsocietyid() {
		return composer_musicsocietyid;
	}

	public void setComposer_musicsocietyid(String composer_musicsocietyid) {
		this.composer_musicsocietyid = composer_musicsocietyid;
	}

	public ComposerBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ComposerBean(String composer_name, Date composer_borndate,
			Date composer_dieddate, String composer_caeipiNumber,
			String composer_musicsocietyid) {
		super();
		this.composer_name = composer_name;
		this.composer_borndate = composer_borndate;
		this.composer_dieddate = composer_dieddate;
		this.composer_caeipiNumber = composer_caeipiNumber;
		this.composer_musicsocietyid = composer_musicsocietyid;
	}

	public long getComposer_id() {
		return composer_id;
	}

	public void setComposer_id(long composer_id) {
		this.composer_id = composer_id;
	}

	public long getCreated_by() {
		return created_by;
	}

	public void setCreated_by(long created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public long getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(long updated_by) {
		this.updated_by = updated_by;
	}

	public Date getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}

	public String getComposer_deletedflag() {
		return composer_deletedflag;
	}

	public void setComposer_deletedflag(String composer_deletedflag) {
		this.composer_deletedflag = composer_deletedflag;
	}

}
