package com.cg.mediacomposer.bean;

import java.sql.Date;

public class ArtistBean {
	private long artist_id;
	private String artist_name;
	private String artist_type;
	private Date artist_borndate;
	private Date artist_dieddate;
	private long created_by;
	private Date created_on;
	private long updated_by;
	private Date updated_on;
	private String artist_deletedflag;
	public String getArtist_name() {
		return artist_name;
	}

	public void setArtist_name(String artist_name) {
		this.artist_name = artist_name;
	}

	public String getArtist_type() {
		return artist_type;
	}

	public void setArtist_type(String artist_type) {
		this.artist_type = artist_type;
	}

	public Date getArtist_borndate() {
		return artist_borndate;
	}

	public void setArtist_borndate(Date artist_borndate) {
		this.artist_borndate = artist_borndate;
	}

	public Date getArtist_dieddate() {
		return artist_dieddate;
	}

	public void setArtist_dieddate(Date artist_dieddate) {
		this.artist_dieddate = artist_dieddate;
	}

	public ArtistBean() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ArtistBean(String artist_name, String artist_type,
			Date artist_borndate, Date artist_dieddate) {
		super();
		this.artist_name = artist_name;
		this.artist_type = artist_type;
		this.artist_borndate = artist_borndate;
		this.artist_dieddate = artist_dieddate;
	}

	public long getCreated_by() {
		return created_by;
	}

	public void setCreated_by(long created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public long getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(long updated_by) {
		this.updated_by = updated_by;
	}

	public Date getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}

	public String getArtist_deletedflag() {
		return artist_deletedflag;
	}

	public void setArtist_deletedflag(String artist_deletedflag) {
		this.artist_deletedflag = artist_deletedflag;
	}

	public long getArtist_id() {
		return artist_id;
	}

	public void setArtist_id(long artist_id) {
		this.artist_id = artist_id;
	}

}
