package com.cg.mediacomposer.bean;

import java.sql.Date;

public class UserBean {
	private long user_id;
	private String user_password;
	private String user_type;
	private long created_by;
	private Date created_on;
	private long updated_by;
	private Date updated_on;

	public long getUser_id() {
		return user_id;
	}

	public void setUser_id(long user_id) {
		this.user_id = user_id;
	}

	public String getUser_password() {
		return user_password;
	}

	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}

	public String getUser_type() {
		return user_type;
	}

	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}

	public long getCreated_by() {
		return created_by;
	}

	public void setCreated_by(long created_by) {
		this.created_by = created_by;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public long getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(long updated_by) {
		this.updated_by = updated_by;
	}

	public Date getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}

	public UserBean(long user_id, String user_password, String user_type) {
		super();
		this.user_id = user_id;
		this.user_password = user_password;
		this.user_type = user_type;
	}

	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}

}
